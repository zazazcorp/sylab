<?php include_once '../model/Projet.class.php' ; ?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="admintab-wrap edu-tab1 mg-t-30">
        <ul class="nav nav-tabs custom-menu-wrap custon-tab-menu-style1">
            <li class="active"><a data-toggle="tab" href="#projet_cours"><span class="edu-icon edu-analytics tab-custon-ic"></span>Projets en cours</a>
            </li>
            <li><a data-toggle="tab" href="#fiche_action_groupe"><span class="edu-icon edu-analytics-arrow tab-custon-ic"></span>Fiches d'actions groupées</a>
            </li>            
        </ul>
        <div class="tab-content">
            <div id="projet_cours" class="tab-pane in active animated flipInX custon-tab-style1">
              <h4>Liste des Projets Acceptés</h4>
              <table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
                  <thead>
                      <tr>
                          <th>N°</th>
                          <th>Promoteur</th>
                          <th>Contact</th>
                          <th>Email</th>
                          <th>Date de soumission</th>            
                          <th>Nom du projet</th>            
                          <th>Proposition de valuer</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>

                      <?php $projets = Projet::afficherAccepte(); $i=1; ?>
                      <?php foreach ($projets as $projet) : ?>

                      <tr class="odd gradeX">
                          <td><?=$i; ?></td>
                          <td><b><?=$projet->nom.' '.$projet->nom; ?></b></td>
                          <td><?=$projet->contact; ?></td>
                          <td><?=$projet->email; ?></td>
                          <td><?=date('d/m/Y',strtotime($projet->date_soumi)); ?></td>
                          <td><b><?=$projet->nom_projet; ?></b></td>             
                          <td><?=$projet->valeur; ?></td>           
                          
                          <td class="center">
                              <a title="Imprimer" target="_blank" class="btn btn-warning" 
                              href="pdf/projet_inbox.php?id_projet=<?=$projet->id_projet?>">                  
                                <span class="fa fa-print"></span>
                              </a>

                              <a title="Fiche d'action spécifique" target="_blank" class="btn btn-primary" 
                              href="https://docs.google.com/document/d/1sdnR-SsFtQ9loHJES6gYVwoAS7Pq87pPg3kc1qTqI3o/edit?ts=5db0a0ea">                  
                                <span class="fa fa-book"></span>
                              </a>

                              <a title="Fiche d'entretien" target="_blank" class="btn btn-danger" 
                              href="https://docs.google.com/document/d/1sdnR-SsFtQ9loHJES6gYVwoAS7Pq87pPg3kc1qTqI3o/edit?ts=5db0a0ea">                  
                                <span class="fa fa-pencil"></span>
                              </a>

                              <a title="Modifier" target="_blank" class="btn btn-primary" 
                              href="https://docs.google.com/document/d/1sdnR-SsFtQ9loHJES6gYVwoAS7Pq87pPg3kc1qTqI3o/edit?ts=5db0a0ea">                  
                                <span class="fa fa-pencil"></span>
                              </a>

                            


                          </td>                                        
                      </tr>
                      <?php $i++; ?> 
                      <?php endforeach; ?>                                      
                  </tbody>
              </table>                
            </div>

            <div id="fiche_action_groupe" class="tab-pane animated flipInX custon-tab-style1">
              <h4>Liste des fiches d'actions groupées</h4>
              <table width="100%" class="table table-striped table-bordered table-hover">
                  <thead>
                      <tr>
                          <th>N°</th>
                          <th>Nombre de projet</th>
                          <th>Description</th>
                          <th>Lien Google Doc</th>
                          <th>Date de création</th>                         
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>

                      <?php $projets = Projet::afficherAccepte(); $i=1; ?>
                      <?php foreach ($projets as $projet) : ?>

                      <tr class="odd gradeX">
                          <td><?=$i; ?></td>
                          <td><b>7</b></td>
                          <td><?=$projet->besoin; ?></td>
                          <td><?=$projet->facebook; ?></td>
                          <td><?=date('d/m/Y',strtotime($projet->date_soumi)); ?></td>
                          <td class="center">
                              <a title="Google Doc" target="_blank" class="btn btn-warning" 
                              href="https://docs.google.com/document/d/1sdnR-SsFtQ9loHJES6gYVwoAS7Pq87pPg3kc1qTqI3o/edit?ts=5db0a0ea">                  
                                <span class="fa fa-print"></span>
                              </a>

                              <a title="Fiche d'action groupée" target="_blank" class="btn btn-primary" 
                              href="https://docs.google.com/document/d/1sdnR-SsFtQ9loHJES6gYVwoAS7Pq87pPg3kc1qTqI3o/edit?ts=5db0a0ea">                  
                                <span class="fa fa-book"></span>
                              </a>                             

                          </td>                                        
                      </tr>
                      <?php $i++; ?> 
                      <?php endforeach; ?>                                      
                  </tbody>
              </table>
                
            </div>

        </div>
    </div>
</div>




<script type="text/javascript">
  $(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>