<!-- Basic Form Start -->
<div class="basic-form-area mg-b-15">
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
        <div class="sparkline8-list mt-b-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>Ajouter un nouveau gérant</h1>
                </div>
            </div>
            <div class="sparkline8-graph">
                <div class="basic-login-form-ad">                    
                    <div class="row">
                    	<form id="form_gerant">
                    		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom</label>
                                        <input type="text" id="nom" required="" class="form-control" placeholder="Nom" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Prénom</label>
                                        <input type="text" id="prenom" required="" class="form-control" placeholder="Prénom" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" id="number" required="" class="form-control" placeholder="Numéro" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" id="email" required="" class="form-control" placeholder="Email" />
                                    </div>                          	                                
	                            </div>
	                        </div>

	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">                         
                                    <div class="form-select-list">
                                    	<label>Droit</label>
                                        <select class="form-control custom-select-value" id="droit" required>
											<option value="gerant">Gérant</option>
											<option value="coach">Coach</option>
											<option value="admin">Administrateur</option>				
										</select><br>
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Mot de passe</label>
                                        <input type="password" id="password" required="" class="form-control" placeholder="password" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Repeat password</label>
                                        <input type="password" id="rpassword" required="" class="form-control" placeholder="Repeter le mot de passe" />
                                    </div>
                                    <div class="form-select-list">
                                    	<label>Statut</label>
                                        <select class="form-control custom-select-value" id="statut" required="">
											<option value="actif">Actif</option>
											<option value="inactif">Inactif</option>				
										</select><br>
                                    </div>
                                    <div class="login-btn-inner">
                                        <div class="inline-remember-me">
                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Ajouter</button>
                                            <label>											
                                        </div>
                                    </div>
                                    <div id="message"></div>	                                
	                            </div>
	                        </div>
                    		
                    	</form>                      
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Basic Form End-->

<script type="text/javascript">
	$('#form_gerant').submit( function()
      {
        var nom = $('#nom').val();
        var prenom = $('#prenom').val();
        var number = $('#number').val();
        var email = $('#email').val();
        var droit = $('#droit').val();
        var password = $('#password').val();
        var rpassword = $('#rpassword').val();
        var statut = $('#statut').val();

        if (password === rpassword) 
        {
        	$.post('../control/add_gerant.php', 
        	  { 
        	  	nom:nom,
        	    prenom:prenom,
        	    number:number,
        	    email:email,
        	    droit:droit,
        	    password:password,
        	    statut:statut
        	  }, 
        	  function(response)
	          {
	            $('#message').html(response);
	          });	          

        }
        else
        {
        	swal("Erreur !","Les Mots de passe de correspondent pas !!!","error");
        } 
        return false;   

      });
</script>

