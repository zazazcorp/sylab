<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="sparkline9-list responsive-mg-b-30">
        <div class="sparkline9-hd">
            <div class="main-sparkline9-hd">
                <h1>Statistique <span class="c3-ds-n">Espaces</span></h1>
            </div>
        </div>
        <div class="sparkline9-graph">
            <div id="stocked"></div>
        </div>
    </div>
</div>
