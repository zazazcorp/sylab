<!-- Basic Form Start -->
<div class="basic-form-area mg-b-15">
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
        <div class="sparkline8-list mt-b-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>Ajouter un nouvel espace</h1>
                </div>
            </div>
            <div class="sparkline8-graph">
                <div class="basic-login-form-ad">                    
                    <div class="row">
                    	<form id="form_espace">
                    		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Intitulé espace</label>
                                        <input type="text" id="intitule" required="" class="form-control" placeholder="Nom de l'espace" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Nombre de chaise</label>
                                        <input type="number" id="place" required="" class="form-control" placeholder="Nombre de place assise" />
                                    </div>                                    
                                                              	                                
	                            </div>
	                        </div>

	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">
                                    <div class="form-group-inner">
                                        <label>Nombre de table</label>
                                        <input type="number" id="table" class="form-control" placeholder="Nombre de table" />
                                    </div> 

                                    <div class="form-group-inner">
                                        <label>Description de l'espace</label>
                                        <input type="text" id="description" class="form-control" placeholder="Ex: Connexion wiifi, Ecran ..." />
                                    </div>                                                  
                                    
                                    <div class="login-btn-inner">
                                        <div class="inline-remember-me">
                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Ajouter</button>
                                            <label>											
                                        </div>
                                    </div>
                                    <div id="message"></div>	                                
	                            </div>
	                        </div>
                    		
                    	</form>                      
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Basic Form End-->

<script type="text/javascript">
	$('#form_espace').submit( function()
      {
        var intitule = $('#intitule').val();
        var place = $('#place').val();
        var table = $('#table').val();
        var description = $('#description').val();        

    	$.post('../control/add_espace.php', 
    	  { 
    	  	intitule:intitule,
    	    place:place,
    	    table:table,
    	    description:description
    	  }, 
    	  function(response)
          {
            $('#message').html(response);
          });	          

         
        return false;   

      });
</script>

