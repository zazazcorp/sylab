<!-- Basic Form Start -->
<div class="basic-form-area mg-b-15">
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
        <div class="sparkline8-list mt-b-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>Ajouter un nouveau visiteur</h1>
                </div>
            </div>
            <div class="sparkline8-graph">
                <div class="basic-login-form-ad">                    
                    <div class="row">
                    	<form id="form_visiteur">
                    		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom</label>
                                        <input type="text" id="nom" required="" class="form-control" placeholder="Nom" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Prénom</label>
                                        <input type="text" id="prenom" required="" class="form-control" placeholder="Prénom" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" id="contact" required="" class="form-control" placeholder="Numéro" />
                                    </div>
                                                              	                                
	                            </div>
	                        </div>

	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" id="email" class="form-control" placeholder="Email" />
                                    </div> 

                                    <div class="form-group-inner">
                                        <label>Profession</label>
                                        <input type="text" id="profession" class="form-control" placeholder="Profession" />
                                    </div>

                                    <div class="form-group-inner">
                                        <label>Structure</label>
                                        <input type="text" id="structure" class="form-control" placeholder="Structure d'origine" />
                                    </div>                           
                                    
                                    <div class="login-btn-inner">
                                        <div class="inline-remember-me">
                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Ajouter</button>
                                            <label>											
                                        </div>
                                    </div>
                                    <div id="message"></div>	                                
	                            </div>
	                        </div>
                    		
                    	</form>                      
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Basic Form End-->

<script type="text/javascript">
	$('#form_visiteur').submit( function()
      {
        var nom = $('#nom').val();
        var prenom = $('#prenom').val();
        var contact = $('#contact').val();
        var email = $('#email').val();
        var profession = $('#profession').val();
        var structure = $('#structure').val();

    	$.post('../control/add_visiteur.php', 
    	  { 
    	  	nom:nom,
    	    prenom:prenom,
    	    contact:contact,
    	    email:email,
    	    profession:profession,
    	    structure:structure
    	  }, 
    	  function(response)
          {
            $('#message').html(response);
          });	          

         
        return false;   

      });
</script>

