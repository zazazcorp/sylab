<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="sparkline-list">
        <div class="smart-sparkline-hd">
            <div class="smart-main-spark-hd">
                <h1>Statistiques <span class="c3-ds-n">Réservation</span> </h1>
            </div>
        </div>
        <div class="smart-sparkline-list">
            <div id="lineChart"></div>
        </div>
    </div>
</div>