<?php include_once '../model/User.class.php' ; ?>
<h4>Liste de tous les gérants</h4>
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>N°</th>
            <th>Nom</th>
            <th>Prénoms</th>
            <th>Numéro</th>
            <th>Email</th>
            <th>Droit</th>
            <th>Statut</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $users = User::afficher(); $i=1; ?>
        <?php foreach ($users as $user) : ?>
        <tr class="odd gradeX">
            <td><?=$i; ?></td>
            <td><?=$user->nom; ?></td>
            <td><?=$user->prenom; ?></td>
            <td><?=$user->contact; ?></td>
            <td><?=$user->email; ?></td>
            <td><?=$user->droit; ?></td>
            <td>            	
            	<?php 
            	   if ($user->statut == 'actif') 
            	   {
            	   	  echo '<span class="btn btn-xs btn-success">Actif</span>';
            	   }
            	   else
            	   {
                      echo '<span class="btn btn-xs btn-danger">Inactif</span>';
            	   }

            	 ?>            	             		
            </td>
            <td class="center">
              
                <!-- Modal delete user -->
                <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#sup'.$i;?>">
                  <span class="fa fa-trash"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='sup'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#sup'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#sup'.$i;?>">
                          Supprimer <b><?=$user->nom.' '.$user->prenom; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/del_user.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_user" value="<?=$user->id_user;?>">
                            <button class="btn btn-danger">
                            <h3>
                                Voulez vous vraiment supprimer cet utilisateur ?                                                 
                            </h3>
                            </button>                                      
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>


                <!-- Modal update user -->
                <button title="Modifier" type="button" class="btn btn-primary" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                  <span class="fa fa-pencil"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#mod'.$i;?>">
                          Modifier <b><?=$user->nom.' '.$user->prenom; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/update_user.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_user" value="<?=$user->id_user;?>">

                            <!-- From update user -->

                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom</label>
                                        <input type="text" name="nom" required="" class="form-control" value="<?=$user->nom;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Prénom</label>
                                        <input type="text" name="prenom" required="" class="form-control" value="<?=$user->prenom;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" name="number" required="" class="form-control" value="<?=$user->contact;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" name="email" required="" class="form-control" value="<?=$user->email;?>" />
                                    </div>                                                            
                              </div>
                          </div>

                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-select-list">
                                      <label>Droit</label>
                                        <select class="form-control custom-select-value" name="droit" required>
                      <option selected value="<?=$user->droit;?>"><?=$user->droit;?></option>
                      <option value="gerant">Gérant</option>
                      <option value="coach">Coach</option>
                      <option value="admin">Administrateur</option>       
                    </select><br>
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Mot de passe</label>
                                        <input type="password" name="password" class="form-control" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Repeat password</label>
                                        <input type="password" name="rpassword" class="form-control"  />
                                    </div>
                                    <div class="form-select-list">
                                      <label>Statut</label>
                                        <select class="form-control custom-select-value" name="statut" required="">
                      <option selected value="<?=$user->statut;?>"><?=$user->statut;?></option>
                      <option value="actif">Actif</option>
                      <option value="inactif">Inactif</option>        
                    </select><br>
                                    </div>
                                                                      
                              </div>
                          </div>

                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">Modifier</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

            </td>                                        
        </tr>
        <?php $i++; ?> 
        <?php endforeach; ?>                                      
    </tbody>
</table>


<script type="text/javascript">
	$(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>