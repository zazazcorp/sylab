<?php include_once '../model/Visiteur.class.php' ; ?>
<h4>Liste de tous les visiteurs</h4>
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>N°</th>
            <th>Nom</th>
            <th>Prénoms</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Profession</th>
            <th>Structure</th>
            <th>Date de visite</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $visiteurs = Visiteur::afficher(); $i=1; ?>
        <?php foreach ($visiteurs as $visiteur) : ?>
        <tr class="odd gradeX">
            <td><?=$i; ?></td>
            <td><?=$visiteur->nom; ?></td>
            <td><?=$visiteur->prenom; ?></td>
            <td><?=$visiteur->email; ?></td>
            <td><?=$visiteur->contact; ?></td>
            <td><?=$visiteur->profession; ?></td>
            <td><?=$visiteur->structure; ?></td>
            <td><?=date('d/m/Y H:i:s',strtotime($visiteur->date_visite)); ?></td>                        
            <td class="center">
                <!-- Modal update visiteur -->
                <?php if ($_SESSION['droit'] == 'admin' OR 
                          $_SESSION['droit'] == 'super_admin' OR
                          $_SESSION['droit'] == 'gerant'): ?>                  
                
                <button title="Modifier" type="button" class="btn btn-primary" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                  <span class="fa fa-pencil"></span>
                </button>
                <?php endif ?>
                <!-- Modal -->
                <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#mod'.$i;?>">
                          Modifier <b><?=$visiteur->nom.' '.$visiteur->prenom; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/update_visiteur.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_visiteur" value="<?=$visiteur->id_visiteur;?>">

                            <!-- From update visiteur -->

                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom</label>
                                        <input type="text" name="nom" required="" class="form-control" value="<?=$visiteur->nom;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Prénom</label>
                                        <input type="text" name="prenom" required="" class="form-control" value="<?=$visiteur->prenom;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" name="contact"  class="form-control" value="<?=$visiteur->contact;?>" />
                                    </div>
                                                                                                
                              </div>
                          </div>

                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" value="<?=$visiteur->email;?>" />
                                    </div>                   
                                    
                                    <div class="form-group-inner">
                                        <label>Profession</label>
                                        <input type="text" name="profession" class="form-control" value="<?=$visiteur->profession;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Structure</label>
                                        <input type="text" name="structure" class="form-control" value="<?=$visiteur->structure;?>" />
                                    </div>                             
                                                                      
                              </div>
                          </div>

                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">Modifier</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

            </td>                                        
        </tr>
        <?php $i++; ?> 
        <?php endforeach; ?>                                      
    </tbody>
</table>


<script type="text/javascript">
	$(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>