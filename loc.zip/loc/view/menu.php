<!-- Start Left menu area -->
<div class="left-sidebar-pro">
    <nav id="sidebar" class="">
        <div class="sidebar-header">
            <a href="index.html"><img class="main-logo" src="../static/img/logo/logo.png" alt="" /></a>
            <strong><a href="index.html"><img src="../static/img/logo/logosn.png" alt="" /></a></strong>
        </div>
        <div class="left-custom-menu-adp-wrap comment-scrollbar">
            <nav class="sidebar-nav left-sidebar-menu-pro">
                <ul class="metismenu" id="menu1">
                    <li>
                        <a title="Landing Page" href="index.php" aria-expanded="false"><span class="educate-icon educate-home icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">Accueil</span></a>
                    </li>

                    <li class="activeTMP">
                        <a class="has-arrow" href="index.html">
							   <span class="educate-icon educate-library icon-wrap"></span>
							   <span class="mini-click-non">Projets</span>
							</a>
                        <ul class="submenu-angle" aria-expanded="true">
                            <li><a title="Inbox" href="index.php?page=inbox"><span class="mini-sub-pro">Inbox</span></a></li>
                            <li><a title="Recevables" href="index.php?page=recevable"><span class="mini-sub-pro">Recevables</span></a></li>
                            <li><a title="Archivés" href="index.php?page=archive"><span class="mini-sub-pro">Archivés</span></a></li>
                            <li><a title="Projets" href="index.php?page=projet"><span class="mini-sub-pro">Gestion</span></a></li>                            
                        </ul>
                    </li>                   
                    <li>
                        <a class="has-arrow" href="all-professors.html" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Espaces</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Ajouter espace" href="index.php?page=add_espace"><span class="mini-sub-pro">Ajouter espace</span></a></li>
                            <li><a title="Liste espace" href="index.php?page=espace"><span class="mini-sub-pro">Espaces</span></a></li>                            
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="all-students.html" aria-expanded="false"><span class="educate-icon educate-message icon-wrap"></span> <span class="mini-click-non">Reservations</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Ajouter Reservation" href="index.php?page=add_reservation"><span class="mini-sub-pro">Nouvelle reservation</span></a></li>
                            <li><a title="Liste Reservation" href="index.php?page=reservation"><span class="mini-sub-pro">Reservations</span></a></li>                            
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Visiteurs</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Ajouter visiteur" href="index.php?page=add_visiteur"><span class="mini-sub-pro">Ajouter un visiteur</span></a></li>
                            <li><a title="Liste  visiteur" href="index.php?page=visiteur"><span class="mini-sub-pro">Liste des visiteurs</span></a></li>                            
                        </ul>
                    </li>

                    <?php if ($_SESSION['droit'] == 'admin' OR 
                          $_SESSION['droit'] == 'super_admin'): ?>
                    <li>

                        <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-professor icon-wrap"></span> <span class="mini-click-non">Gérants</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Ajouter un gerant" href="index.php?page=add_gerant"><span class="mini-sub-pro">Ajouter un gérant</span></a></li>
                            <li><a title="Liste gerant" href="index.php?page=gerant"><span class="mini-sub-pro">Liste des gérants</span></a></li>                            
                        </ul>
                    </li>
                    <?php endif ?>
                    <li>
                        <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-charts icon-wrap"></span> <span class="mini-click-non">Statistiques</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Statistiques projets" href="index.php?page=stat_projet"><span class="mini-sub-pro">Projets</span></a></li>
                            <li><a title="Statistiques espace" href="index.php?page=stat_espace"><span class="mini-sub-pro">Espaces</span></a></li>
                            <li><a title="Statistiques reservation" href="index.php?page=stat_reservation"><span class="mini-sub-pro">Reservations</span></a></li>                            
                            <!-- <li><a title="Statistiques visiteurs" href="index.php?page=stat_visiteur"><span class="mini-sub-pro">Visiteurs</span></a></li> -->
                        </ul>
                    </li>                   
                </ul>
            </nav>
        </div>
    </nav>
</div>
<!-- End Left menu area -->