<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="sparkline10-list">
        <div class="sparkline10-hd">
            <div class="main-sparkline10-hd">
                <h1>Statistiques <span class="c3-ds-n">Projets</span></h1>
            </div>
        </div>
        <div class="sparkline10-graph">
            <div id="pie"></div>
        </div>
    </div>
</div>
