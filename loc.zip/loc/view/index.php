<?php
    session_start();
    if ($_SESSION['id']) {      
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SyLAB | Système de Gestion de BeoogoLAB</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/png" href="../static/img/favicon.png">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/owl.carousel.css">
    <link rel="stylesheet" href="../public/vendor/css/owl.theme.css">
    <link rel="stylesheet" href="../public/vendor/css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/main.css">
    <!-- educate icon CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/educate-custon-icon.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="../public/vendor/css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="../public/vendor/css/calendar/fullcalendar.print.min.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/responsive.css">

    <!-- Chart CSS
    ============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/c3/c3.min.css">

    <!-- tabs CSS
        ============================================ -->
    <link rel="stylesheet" href="../public/vendor/css/tabs.css">

    <!-- Sweat Alert
        ============================================ -->
    <link rel="stylesheet" href="../public/sweat_allert/sweetalert.css">
    <!-- Datatable -->
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <!-- modernizr JS
		============================================ -->
    <script src="../public/vendor/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- jquery
        ============================================ -->
    <script src="../public/vendor/js/vendor/jquery-1.12.4.min.js"></script>
</head>
<body>
	<!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->


    <?php   

    $page = isset($_GET['page']) ? $_GET['page'] : 'accueil';

    ob_start();

    /* INCLUSION DES PAGES  */

    switch ($page) {
        case 'accueil':
            require_once 'accueil.php';
            break;               

        case 'gerant':
            require_once 'gerant.php';
            break;

        case 'visiteur':
            require_once 'visiteur.php';
            break;

        case 'espace':
            require_once 'espace.php';
            break;

        case 'reservation':
            require_once 'reservation.php';
            break;

        case 'inbox':
            require_once 'inbox.php';
            break;

        case 'recevable':
            require_once 'recevable.php';
            break;

        case 'archive':
            require_once 'archive.php';
            break;

        case 'projet':
            require_once 'projet.php';
            break;


        case 'add_gerant':
            require_once 'add_gerant.php';
            break;

        case 'add_visiteur':
            require_once 'add_visiteur.php';
            break;

        case 'add_espace':
            require_once 'add_espace.php';
            break;

        case 'add_reservation':
            require_once 'add_reservation.php';
            break;



        case 'statistique':
            require_once 'statistique.php';
            break;

        case 'stat_projet':
            require_once 'stat_projet.php';
            break;

        case 'stat_espace':
            require_once 'stat_espace.php';
            break;

        case 'stat_reservation':
            require_once 'stat_reservation.php';
            break;

        case 'stat_visiteur':
            require_once 'stat_visiteur.php';
            break;


          
        default:
            require_once 'accueil.php';
            break;
    }


    $content = ob_get_clean();

    ?>




    
    <?php include_once"menu.php"; ?>


    <!-- Dynamique call for pages -->
    <div class="all-content-wrapper">
    	<?php include_once"navbar.php"; ?>

    	<!-- Load pages form get here -->
    	<div class="container-fluid"><?=$content?></div>

    	<!-- Footer copyright -->
    	<!-- <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Copyright © 2019. All rights reserved. by <a href="https://beoogolab.org">BeoogoLAB</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->  	
    </div>
     
    <!-- bootstrap JS
		============================================ -->
    <script src="../public/vendor/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="../public/vendor/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="../public/vendor/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="../public/vendor/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="../public/vendor/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="../public/vendor/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="../public/vendor/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="../public/vendor/js/counterup/jquery.counterup.min.js"></script>
    <script src="../public/vendor/js/counterup/waypoints.min.js"></script>
    <script src="../public/vendor/js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="../public/vendor/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../public/vendor/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="../public/vendor/js/metisMenu/metisMenu.min.js"></script>
    <script src="../public/vendor/js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="../public/vendor/js/morrisjs/raphael-min.js"></script>
    <script src="../public/vendor/js/morrisjs/morris.js"></script>
    <script src="../public/vendor/js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="../public/vendor/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="../public/vendor/js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="../public/vendor/js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="../public/vendor/js/calendar/moment.min.js"></script>
    <script src="../public/vendor/js/calendar/fullcalendar.min.js"></script>
    <script src="../public/vendor/js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="../public/vendor/js/plugins.js"></script>

    <!-- c3 JS
    ============================================ -->
    <script src="../public/vendor/js/c3-charts/d3.min.js"></script>
    <script src="../public/vendor/js/c3-charts/c3.min.js"></script>
    <script src="../public/vendor/js/c3-charts/c3-active.js"></script>

    <!-- tab JS
        ============================================ -->
    <script src="../public/vendor/js/tab.js"></script>
    <!-- main JS
		============================================ -->
    <script src="../public/vendor/js/main.js"></script>
    <!-- datatables -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

    <!-- Sweat Alert
        ============================================ -->
    <script src="../public/sweat_allert/sweetalert.min.js"></script>

    <!-- tawk chat JS
		============================================ -->
    <!-- <script src="../public/vendor/js/tawk-chat.js"></script> -->

</body>
</html>

<?php }
    else
    {
        header('Location:login.php');
    }

 ?>