<!-- Basic Form Start -->
<div class="basic-form-area mg-b-15">
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
        <div class="sparkline8-list mt-b-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>Enregistrer une nouvelle reservation</h1>
                </div>
            </div>
            <div class="sparkline8-graph">
                <div class="basic-login-form-ad">                    
                    <div class="row">
                    	<form id="form_reservation">
                    		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom et prénoms du client</label>
                                        <input type="text" id="client" required="" class="form-control" placeholder="Nom & Prénoms" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" id="contact" required="" class="form-control" placeholder="Ex:70809010" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" id="email" required="" class="form-control" placeholder="Email du client" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Date de début</label>
                                        <input type="date" id="debut" required="" class="form-control"/>
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Date de fin</label>
                                        <input type="date" id="fin" required="" class="form-control"/>
                                    </div>
                                                              	                                
	                            </div>
	                        </div>

	                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	                            <div class="basic-login-inner">
                                    <div class="form-group-inner">
                                        <label>Objet de la reservation</label>
                                        <input type="text" id="objet" class="form-control" placeholder="Objet" />
                                    </div> 

                                    <div class="form-group-inner">
                                        <label>Nombre de personne</label>
                                        <input type="number" id="personne" class="form-control" required placeholder="Nombre de personne" />
                                    </div>

                                    <div class="form-group-inner">
                                        <label>Statut de la reservation</label>
                                        <select class="form-control custom-select-value" id="statut" required>
                                            <option value="non paye">Reservé non payé</option>
                                            <option value="paye">Reservé payé</option>                  
                                        </select><br>
                                    </div>

                                    <div class="form-group-inner">
                                        <label>Espace conserné</label>

                                    <?php 
                                        include_once'../model/Espace.class.php';
                                        $spaces = Espace::afficher(); 
                                    ?>
                                        <select class="form-control custom-select-value" id="espace" required>
                                    <?php foreach ($spaces as $space): ?>

                                            <option value="<?=$space->id_espace;?>">
                                                <?=$space->intitule;?>
                                            </option>                                    

                                    <?php endforeach ?>

                                        </select><br>
                                    </div>                           
                                    
                                    <div class="login-btn-inner">
                                        <div class="inline-remember-me">
                                            <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">Ajouter</button>
                                            <label>											
                                        </div>
                                    </div>
                                    <div id="message"></div>	                                
	                            </div>
	                        </div>
                    		
                    	</form>                      
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Basic Form End-->

<script type="text/javascript">
	$('#form_reservation').submit( function()
      {
        var client = $('#client').val();
        var contact = $('#contact').val();
        var email = $('#email').val();
        var debut = $('#debut').val();
        var fin = $('#fin').val();
        var objet = $('#objet').val();
        var personne = $('#personne').val();
        var statut = $('#statut').val();
        var espace = $('#espace').val();

    	$.post('../control/add_reservation.php', 
    	  { 
    	  	client:client,
    	    contact:contact,
    	    email:email,
    	    debut:debut,
    	    fin:fin,
    	    objet:objet,
            personne:personne,
            statut:statut,
            espace:espace
    	  }, 
    	  function(response)
          {
            $('#message').html(response);
          });	          

         
        return false;   

      });
</script>

