<?php include_once '../model/Projet.class.php' ; ?>
<h4>Boite de reception de Projets soumis</h4>
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>N°</th>
            <th>Promoteur</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Date de soumission</th>            
            <th>Nom du projet</th>            
            <th>Proposition de valuer</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php $projets = Projet::afficherInbox(); $i=1; ?>
        <?php foreach ($projets as $projet) : ?>

        <tr class="odd gradeX">
            <td><?=$i; ?></td>
            <td><b><?=$projet->nom.' '.$projet->nom; ?></b></td>
            <td><?=$projet->contact; ?></td>
            <td><?=$projet->email; ?></td>
            <td><?=date('d/m/Y',strtotime($projet->date_soumi)); ?></td>
            <td><b><?=$projet->nom_projet; ?></b></td>             
            <td><?=$projet->valeur; ?></td>           
            
            <td class="center">
                <a title="Imprimer" target="_blank" class="btn btn-success" 
                href="pdf/projet_inbox.php?id_projet=<?=$projet->id_projet?>">        
                  <span class="fa fa-print"></span>
                </a>

                <!-- Modal Archiver projet -->
                <button title="Archiver" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#sup'.$i;?>">
                  <span class="fa fa-book"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='sup'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#sup'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#sup'.$i;?>">
                          Archiver ce projet: <b><?=$projet->client; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/archiver_projet.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_projet" value="<?=$projet->id_projet;?>">
                            <button class="btn btn-warning">
                            <h4>
                                Voulez vous vraiment mettre ce projet dans les archives ?                                                 
                            </h4>
                            </button>                                      
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-danger" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-success">OUI</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Modal recevable projet -->
                <button title="Recevable" type="button" class="btn btn-primary" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                  <span class="fa fa-pencil"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#mod'.$i;?>">
                          Projet Recevable ? <b><?=$projet->client; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/recevable_projet.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_projet" value="<?=$projet->id_projet;?>">

                            <!-- From update projet -->

                              <button class="btn btn-warning">
                            <h4>
                                Ce projet est-il vraiment recevable ?                                                 
                            </h4>
                            </button>                         

                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-danger" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-success">OUI</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>




            </td>                                        
        </tr>
        <?php $i++; ?> 
        <?php endforeach; ?>                                      
    </tbody>
</table>


<script type="text/javascript">
  $(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>