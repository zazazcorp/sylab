<?php include_once '../model/Espace.class.php' ; ?>
<h4>Liste de tous les espaces enrégistrés</h4>
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>N°</th>
            <th>Intitulé espace</th>
            <th>Nombre de place assise</th>
            <th>Nombre de table</th>
            <th>Description</th>            
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $espaces = Espace::afficher(); $i=1; ?>
        <?php foreach ($espaces as $espace) : ?>
        <tr class="odd gradeX">
            <td><?=$i; ?></td>
            <td><?=$espace->intitule; ?></td>
            <td><?="<span class='btn btn-xs btn-success'>$espace->place</span>"; ?></td>
            <td><?="<span class='btn btn-xs btn-danger'>$espace->nb_table</span>"; ?></td>
            <td><?=$espace->description; ?></td>           
            
            <td class="center">

                <!-- Modal delete espace -->
                <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#sup'.$i;?>">
                  <span class="fa fa-trash"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='sup'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#sup'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#sup'.$i;?>">
                          Supprimer <b><?=$espace->intitule; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/del_espace.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_espace" value="<?=$espace->id_espace;?>">
                            <button class="btn btn-danger">
                            <h3>
                                Voulez vous vraiment supprimer cet espace ?                                                 
                            </h3>
                            </button>                                      
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>


                <!-- Modal update espace -->
                <button title="Modifier" type="button" class="btn btn-primary" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                  <span class="fa fa-pencil"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#mod'.$i;?>">
                          Modifier <b><?=$espace->intitule; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/update_espace.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_espace" value="<?=$espace->id_espace;?>">

                            <!-- From update espace -->

                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Intitulé espace</label>
                                        <input type="text" name="intitule" required="" class="form-control" value="<?=$espace->intitule;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Nombre de place</label>
                                        <input type="number" name="place" required="" class="form-control" value="<?=$espace->place;?>" />
                                    </div>
                                                                                                
                              </div>
                          </div>

                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">
                                <div class="form-group-inner">
                                        <label>Nombre de table</label>
                                        <input type="number" name="table" required="" class="form-control" value="<?=$espace->nb_table;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Description</label>
                                        <input type="text" name="description" required="" class="form-control" value="<?=$espace->description;?>" />
                                    </div>                                    
                                                                      
                              </div>
                          </div>

                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">Modifier</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

            </td>                                        
        </tr>
        <?php $i++; ?> 
        <?php endforeach; ?>                                      
    </tbody>
</table>


<script type="text/javascript">
  $(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>