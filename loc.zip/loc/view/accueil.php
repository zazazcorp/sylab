<?php 
    include_once'../model/Projet.class.php';
    include_once'../model/Reservation.class.php';
    include_once'../model/Espace.class.php';
    include_once'../model/Visiteur.class.php';

    $accepte = Projet::countAccepte();
    $visiteur = Visiteur::countAll();
    $reservation = Reservation::countAll();
    $espace = Espace::countAll();   
?>

<div class="analytics-sparkle-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content">
                        <h5>Projets en cours</h5>
                        <h2>
                        	<span class="counter">
                                <?=$accepte[0]->accepte?>
                            </span> 
                        	<span class="tuition-fees">Projets en cours</span>
                        </h2>
                        <span class="text-success">40%</span>
                        <div class="progress m-b-0">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:40%;"> <span class="sr-only">40% Complete</span> </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="analytics-sparkle-line reso-mg-b-30">
                    <div class="analytics-content">
                        <h5>Reservations</h5>
                        <h2>
                        	<span class="counter">
                                <?=$reservation[0]->total;?>
                            </span> 
                        	<span class="tuition-fees">En cours</span>
                        </h2>
                        <span class="text-danger">60%</span>
                        <div class="progress m-b-0">
                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:60%;"> <span class="sr-only">60% Complete</span> </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="analytics-sparkle-line reso-mg-b-30 table-mg-t-pro dk-res-t-pro-30">
                    <div class="analytics-content">
                        <h5>Espaces</h5>
                        <h2>
                        	<span class="counter">
                               <?=$espace[0]->total;?>   
                            </span> 
                        	<span class="tuition-fees">Disponibles</span>
                        </h2>
                        <span class="text-info">50%</span>
                        <div class="progress m-b-0">
                            <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%;"> <span class="sr-only">50% Complete</span> </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                    <div class="analytics-content">
                        <h5>Visisteurs</h5>
                        <h2>
                        	<span class="counter">
                               <?=$visiteur[0]->total;?>   
                            </span> 
                        	<span class="tuition-fees">visiteurs</span>
                        </h2>
                        <span class="text-inverse">50%</span>
                        <div class="progress m-b-0">
                            <div class="progress-bar progress-bar-inverse" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%;"> <span class="sr-only">50% Complete</span> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 