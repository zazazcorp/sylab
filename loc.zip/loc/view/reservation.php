<?php include_once '../model/Reservation.class.php' ; ?>
<h4>Liste de toutes les reservations</h4>
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>N°</th>
            <th>Client</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Date de début</th>            
            <th>Date de fin</th>
            <th>Objet</th>
            <th>Nombre de personne</th>
            <th>Statut</th>
            <th>Espace conserné</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>

        <?php $reservs = Reservation::afficher(); $i=1; ?>
        <?php foreach ($reservs as $reservation) : ?>

        <tr class="odd gradeX">
            <td><?=$i; ?></td>
            <td><?=$reservation->client; ?></td>
            <td><?=$reservation->contact; ?></td>
            <td><?=$reservation->email; ?></td>
            <td><?=date('d/m/Y',strtotime($reservation->debut)); ?></td>
            <td><?=date('d/m/Y',strtotime($reservation->fin)); ?></td>
            <td><?=$reservation->objet; ?></td>
            <td><?=$reservation->personne; ?></td>            
            <td>
          <?php 
              if ($reservation->statut == 'non paye') 
              {
                echo"<span class='btn btn-xs btn-danger'>$reservation->statut</span>";
              }
              elseif ($reservation->statut == 'paye') 
              {
                echo"<span class='btn btn-xs btn-success'>$reservation->statut</span>";
              }
              else
              {
                echo"<span class='btn btn-xs btn-warning'>$reservation->statut</span>";
              }                
          ?>
            </td>
            
            <td>              
          <?php 
              include_once'../model/Espace.class.php';
              $space = Espace::afficherOne($reservation->espace);
              echo $space[0]->intitule;
          ?>                
            </td>           
            
            <td class="center">

                <!-- Modal delete reservation -->
                <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#sup'.$i;?>">
                  <span class="fa fa-trash"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='sup'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#sup'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#sup'.$i;?>">
                          Supprimer <b><?=$reservation->client; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/del_reservation.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_reservation" value="<?=$reservation->id_reservation;?>">
                            <button class="btn btn-danger">
                            <h3>
                                Voulez vous vraiment supprimer cette reservation ?                                                 
                            </h3>
                            </button>                                      
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Modal update reservation -->
                <button title="Modifier" type="button" class="btn btn-primary" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                  <span class="fa fa-pencil"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#mod'.$i;?>">
                          Modifier <b><?=$reservation->client; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/update_reservation.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_reservation" value="<?=$reservation->id_reservation;?>">

                            <!-- From update reservation -->

                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Nom et prénoms du client</label>
                                        <input type="text" name="client" required="" class="form-control" value="<?=$reservation->client;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Contact</label>
                                        <input type="number" name="contact" required="" class="form-control" value="<?=$reservation->contact;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Email</label>
                                        <input type="email" name="email" required="" class="form-control" value="<?=$reservation->email;?>" />
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Date de début</label>
                                        <input type="date" name="debut" required="" class="form-control" value="<?=$reservation->debut;?>"/>
                                    </div>
                                    <div class="form-group-inner">
                                        <label>Date de fin</label>
                                        <input type="date" name="fin" required="" class="form-control" value="<?=$reservation->fin;?>"/>
                                    </div>
                                                                                                
                              </div>
                          </div>

                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                              <div class="basic-login-inner">
                                    <div class="form-group-inner">
                                        <label>Objet de la reservation</label>
                                        <input type="text" name="objet" class="form-control" value="<?=$reservation->objet;?>" />
                                    </div> 

                                    <div class="form-group-inner">
                                        <label>Nombre de personne</label>
                                        <input type="number" name="personne" class="form-control" required value="<?=$reservation->personne;?>" />
                                    </div>

                                    <div class="form-group-inner">
                                        <label>Statut de la reservation</label>
                                        <select class="form-control custom-select-value" name="statut" required>
                                            <option selected value="<?=$reservation->statut;?>" >
                                              <?=$reservation->statut;?>                                              
                                            </option>
                                            <option value="non paye">Reservé non payé</option>
                                            <option value="paye">Reservé payé</option>
                                            <option value="annule">Reservation Annulée</option>                  
                                        </select><br>
                                    </div>

                                    <div class="form-group-inner">
                                        <label>Espace conserné</label>

                                    <?php 
                                        include_once'../model/Espace.class.php';
                                        $spaces = Espace::afficher(); 
                                    ?>
                                        <select class="form-control custom-select-value" name="espace" required>
                                          <option selected value="<?=$reservation->espace;?>">
                                    <?php 
                                    $spa = Espace::afficherOne($reservation->espace);
                                    echo $spa[0]->intitule;

                                    ?>
                                            
                                          </option>
                                    <?php foreach ($spaces as $space): ?>

                                            <option value="<?=$space->id_espace;?>">
                                                <?=$space->intitule;?>
                                            </option>                                    

                                    <?php endforeach ?>

                                        </select><br>
                                    </div>                         
                                    
                                                                                                         
                              </div>
                          </div>                            

                          

                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">Modifier</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Modal Notifier reservation -->
                <button title="Notifier" type="button" class="btn btn-warning" data-toggle="modal" data-target="<?='#not'.$i;?>">
                  <span class="educate-icon educate-bell"></span>
                </button>
                <!-- Modal -->
                <div class="modal fade" id="<?='not'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#not'.$i;?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="<?='#not'.$i;?>">
                          Notifier <b><?=$reservation->client; ?></b>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <form method="post" action="../control/notifier_reservation.php">
                          <div class="modal-body">                           
                            <input type="hidden" name="id_reservation" value="<?=$reservation->id_reservation;?>">
                            <input type="hidden" name="client" value="<?=$reservation->client;?>">
                            <input type="hidden" name="contact" value="<?=$reservation->contact;?>">
                            <input type="hidden" name="email" value="<?=$reservation->email;?>">

                            <!-- From update reservation -->

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                              <div class="basic-login-inner">                         
                                    <div class="form-group-inner">
                                        <label>Votre message</label>
                                        <input type="text" name="content" required="" class="form-control" placeholder="Votre message" />
                                    </div>                              
                                                                   
                              </div>
                            </div>
                         
                            <!-- / end form  -->
                                                                  
                          </div>
                          <div class="modal-footer">                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                            <button type="submit" name="submit" class="btn btn-primary">Envoyer</button>
                          </div>                                                      
                      </form>
                    </div>
                  </div>
                </div>




            </td>                                        
        </tr>
        <?php $i++; ?> 
        <?php endforeach; ?>                                      
    </tbody>
</table>


<script type="text/javascript">
  $(document).ready( function () {
        $('#myTable').DataTable();
     } );
</script>