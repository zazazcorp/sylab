<?php session_start(); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>Projet_inbox</title>
   
</head>
<body>
	<?php
		include_once'../../model/Projet.class.php';
		require_once("../../public/fpdf/fpdf.php");

		$id_projet = $_GET['id_projet'];

		if(isset($id_projet) AND $_SESSION['id'] )
		{
			/*// Activation de la classe
			$projet = $connect->prepare("SELECT * FROM projet WHERE numprojet =?");
			$projet->execute(array($_GET['id']));
			$retour=$projet->fetch();*/

			$projet = Projet::afficherOne($id_projet);

			$titre = utf8_decode('Projet N°'.$id_projet.' : '.$projet[0]->nom_projet);
			
			class PDF extends FPDF
			{
				protected $col = 0; // Colonne courante
				protected $y0;      // Ordonnée du début des colonnes

				function Header()
				{
				    // En-tête
				    global $titre;

				    $this->SetFont('Arial','',17);
				    $w = $this->GetStringWidth($titre)+30;
				    //$this->SetX((210-$w)/2);
				    $this->SetDrawColor(5,6,9);
				    $this->SetFillColor(211,211,211);
					//$this->SetFillColor(200,220,255);
				    //$this->SetFillColor(230,230,0);
				    $this->SetTextColor(144, 18, 18);
				    $this->SetLineWidth(1);
				    $this->Image('fond_pdf.jpg', 0, 0, $this->GetPageWidth(), $this->GetPageHeight());
				    $this->MultiCell(185, 8, $titre,1 ,'C', 'true');
				    //$this->Cell($this->GetPageWidth()-24,9,'PROJET : '.$titre,1,1,'C',true);
				    $this->Ln(10);
				    // Sauvegarde de l'ordonnée
				    $this->y0 = $this->GetY();
				}

				function Footer()
				{
				    // Pied de page
				    $this->SetY(-15);
				    $this->SetFont('Arial','BI',8);
				    $this->SetTextColor(128);
				    $this->Cell(0,10,'Page '.$this->PageNo().' www.beoogolab.org',0,0,'R');
				}

				function SetCol($col)
				{
				    // Positionnement sur une colonne
				    $this->col = $col;
				    $x = 10+$col*96;
				    $this->SetLeftMargin($x);
				    $this->SetX($x);
				}

				function AcceptPageBreak()
				{
				    // Méthode autorisant ou non le saut de page automatique
				    if($this->col<1)
				    {
				        // Passage à la colonne suivante
				        $this->SetCol($this->col+1);
				        // Ordonnée en haut
				        $this->SetY($this->y0);
				        // On reste sur la page
				        return false;
				    }
				    else
				    {
				        // Retour en première colonne
				        $this->SetCol(0);
				        // Saut de page
				        return true;
				    }
				}

				function AjouterCellule($libelle, $ecrire)
					{
					    // Police
					    $this->SetFont('Times','B',10);
					    // Sortie du texte sur 6 cm de largeur
					    //$this->Text($this->GetX(), $this->GetY(), strtoupper($libelle));
					    $libelle=strtoupper($libelle);
					    $this->MultiCell(90, 5, strtoupper($libelle), 1, 'J');
					    //$this->Line($this->GetX()-1, $this->GetY()+1, $this->GetX()+$this->GetStringWidth($libelle), $this->GetY()+1);
					    $this->Ln();
					    $this->SetFont('Times','',13);
					    $this->MultiCell(90,5,$ecrire);
					    $this->Ln();
					    // Retour en première colonne
					    //$this->SetCol(0);
					}

					
			}

			$pdf = new PDF('P','mm','A4');
			//$pdf->SetAutoPageBreak(true);
			$pdf->AddPage();

			$pdf->SetTitle(utf8_decode($projet[0]->nom_projet));

			if(!empty($projet[0]->nom_projet)){
				//$pdf->AjouterCellule(utf8_decode('Entreprise'), utf8_decode($retour['entreprise']));
			}
			if(!empty($projet[0]->nom)){
			$pdf->AjouterCellule(utf8_decode('Promoteur du projet'), 
				utf8_decode($projet[0]->civilite.' '.$projet[0]->nom.' '.$projet[0]->prenom));
			}
			if(!empty($retour['Forme juridique de l\'entreprise'])){
			$pdf->AjouterCellule(utf8_decode('Forme juridique'), utf8_decode($projet[0]->form_juri));
			}
			
			if(!empty($projet[0]->besoin)){
			$pdf->AjouterCellule(utf8_decode('Capitaux recherches'), utf8_decode($projet[0]->besoin).' Francs CFA');	
			}
			if(!empty($projet[0]->valeur)){
			$pdf->AjouterCellule(utf8_decode('Service offert par l\'entreprise'),
			   utf8_decode($projet[0]->valeur));
			}
			if(!empty($projet[0]->client)){
			$pdf->AjouterCellule(utf8_decode('Segments de clients vises'), 
				utf8_decode($projet[0]->client));	
			}
			
			
			if(!empty($retour['avancement'])){
				$pdf->AjouterCellule(utf8_decode('Etat d\'avancement du projet'), utf8_decode($retour['avancement']));
			}
			if(!empty($projet[0]->avancement)){
				$pdf->AjouterCellule(utf8_decode('Vision et ambition de l\'entreprise'), 
					utf8_decode($projet[0]->avancement));
			}
		
			if(!empty($projet[0]->categorie)){
				$pdf->AjouterCellule(utf8_decode('Catégorie'), 
					utf8_decode($projet[0]->categorie));
			}
			if(!empty($projet[0]->partenaire)){
				$pdf->AjouterCellule(utf8_decode('Partenaires clés'), 
					utf8_decode($projet[0]->partenaire));
			}
			


			//$pdf->Text()
			//$pdf->AjouterChapitre($retour['entreprise']);
			//$pdf->AjouterChapitre($retour['entreprise']);

			$pdf->Output();

		}

    ?>
</body>
</html>