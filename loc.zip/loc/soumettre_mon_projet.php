<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>BeoogoLAB - SyLAB | Soumettre un projet</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/png" href="static/img/favicon.png">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/owl.carousel.css">
    <link rel="stylesheet" href="public/vendor/css/owl.theme.css">
    <link rel="stylesheet" href="public/vendor/css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/normalize.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/main.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="public/vendor/css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="public/vendor/css/calendar/fullcalendar.print.min.css">
    <!-- forms CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/form/all-type-forms.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="public/vendor/css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="public/vendor/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
	<div class="container">
		<div class="row">
			<div class="text-center custom-login">				
                <img src="static/img/logo/logo.png"><br>
                <h3 class="alert alert-warning"> 
                    Veuillez remplir le formulaire pour soumettre votre projet
                </h3>				
			</div>
            
			<div class="content-error">
				<div class="hpanel">
                    <div class="panel-body">
                        <form method="post" action="control/add_projet.php" id="loginForm">
                            <!-- Part 1 -->
                            <div class="sparkline8-list mt-b-30">
                                <div class="sparkline8-hd">
                                    <div class="main-sparkline8-hd">
                                        <h3>Informations générales</h3>
                                    </div>
                                    <div>
                                        <h4 class="alert alert-danger">
                                            Les champs suivis d'étoile (<strong>*</strong>) sont obligatoires
                                        </h4>
                                    </div>
                                </div>
                                <div class="sparkline8-graph">
                                    <div class="basic-login-form-ad">                    
                                        <div class="row">
                                            
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="basic-login-inner">                         
                                                        <div class="form-group-inner">
                                                            <label> 
                                                                Votre civilité 
                                                                <i style="color: red">*</i>
                                                            </label>
                                                            <input type="text" name="civilite" required="" class="form-control" placeholder="Civilité" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Votre nom *</label>
                                                            <input type="text" name="nom" required="" class="form-control" placeholder="Nom" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Prénom *</label>
                                                            <input type="text" name="prenom" required="" class="form-control" placeholder="Prénom" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Date de naissance *</label>
                                                            <input type="date" name="dob" required="" class="form-control" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Pays de résidence *</label>
                                                            <input type="text" name="pays_r" required="" class="form-control" placeholder="Pays de résidence" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Ville de résidence *</label>
                                                            <input type="text" name="ville_r" required="" class="form-control" placeholder="Ville de résidence" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Numero de téléphone *</label>
                                                            <input type="number" name="contact" required="" class="form-control" placeholder="Téléphone sans indicatif du pays" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Adresse mail *</label>
                                                            <input type="email" name="email" required="" class="form-control" placeholder="Email" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Adresse Facebook</label>
                                                            <input type="text" name="fb"  class="form-control" placeholder="Adresse de profile Facebook" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Adresse Twitter</label>
                                                            <input type="text" name="tw" class="form-control" placeholder="Adresse de profile twitter" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Formation academique ou certification en relation avec votre projet ? (précisez le Domaine, Etablissement ou institution de formation, Diplôme ou Attestation)</label>                
                                                            <textarea class="form-control" name="form_aca" name="story"rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Experiences professionnelles en relation avec votre projet ? (précisez le Domaine, Structure, Tâches de responsabilité, Durée)</label>                
                                                            <textarea class="form-control" name="exp_pro" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>                                    
                                                                                                                    
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="basic-login-inner"> 

                                                        <div class="form-group-inner">
                                                            <label>Nom de votre projet *</label>
                                                            <input type="text" name="nom_projet" required class="form-control" placeholder="Le nom de votre projet" />
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Présentez le projet en 1000 lignes max *</label>                
                                                            <textarea required class="form-control"  name="pre_projet"rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Choisir une catégorie pour votre projet *</label>

                                                            <select required name="cate" class="form-control">
                                                                <option value="Experience client"> Experience client
                                                                    
                                                                </option>
                                                                <option value="Solution digitale pour entreprise"> Solution digitale pour entreprise
                                                                    
                                                                </option>
                                                                <option value="Objets connectés"> Objets connectés
                                                                    
                                                                </option>
                                                                <option value="Réseaux sociaux, services communautaires"> Réseaux sociaux, services communautaires
                                                                    
                                                                </option>
                                                                <option value="E-commerce"> E-commerce
                                                                    
                                                                </option>
                                                                <option value="Vie pratique, contenus locaux"> Vie pratique, contenus locaux
                                                                    
                                                                </option>
                                                                <option value="Paiement par mobile & transfert d'argent"> Paiement par mobile & transfert d'argent
                                                                    
                                                                </option>
                                                                <option value="Education, Santé"> Education, Santé
                                                                    
                                                                </option>
                                                                <option value="Agriculture"> Agriculture
                                                                    
                                                                </option>
                                                                <option value="Autre"> Autre
                                                                    
                                                                </option>
                                                                
                                                            </select>                
                                                            
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Forme juridique de votre entreprise si déjà créée</label>
                                                            <select name="rccm" class="form-control">
                                                                <option value="------">
                                                                    ------
                                                                    
                                                                </option>
                                                                <option value="S.A.R.L.">
                                                                    S.A.R.L.
                                                                    
                                                                </option>
                                                                <option value="S.A.S.">
                                                                    S.A.S.
                                                                    
                                                                </option>
                                                                <option value="S.A.">
                                                                    S.A.
                                                                    
                                                                </option>
                                                                <option value="S.I.">
                                                                    S.I.
                                                                    
                                                                </option>
                                                            </select>
                                                            <div class="form-group-inner">
                                                                <label>Lien de votre solution</label>
                                                                <input type="text" name="lien_sol" class="form-control" placeholder="Le lien de votre solution" />
                                                            </div>
                                                            <div class="form-group-inner">
                                                                <label>Etat d'avancement de du ptojet *</label>
                                                                <select required="" name="avancement" class="form-control">
                                                                    <option value="Etape d'idée"> Etape d'idée
                                                                        
                                                                    </option>
                                                                    <option value="Idée maturée"> Idée maturée
                                                                        
                                                                    </option>
                                                                    <option value="Déjà lancé"> Déjà lancé
                                                                        
                                                                    </option>
                                                                    <option value="Lancé et en pleine croissance"> Lancé et en pleine croissance
                                                                        
                                                                    </option>
                                                                    <option value="Autre état"> Autre état
                                                                        
                                                                    </option>
                                                                    
                                                                </select>
                                                            </div>
                                                            <div class="form-group-inner">
                                                            <label>Enumerez tous les membres de votre équipe en précisant pour chacun d'eux les informations suivantes : Nom, prénoms, date de naissance, compétance </label>                
                                                            <textarea class="form-control"  name="team"rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Déjà participé à un programme d'incubation ou d'accélération, précisez la structure, décrivez les services dont vous avez bénéficié pendant le programme d'incubation ou d'accélération</label>                
                                                            <textarea class="form-control"  name="incub"rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Déjà obtenu un financement dans le cadre de ce projet, précisez la structure, les conditions de financement </label>                
                                                            <textarea class="form-control"  name="finance"rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        </div>                                                            
                                                    </div>
                                                </div>
                                                
                                                                
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Part 1 -->

                            <!-- Part 2 -->
                            <div class="sparkline8-list mt-b-30">
                                <div class="sparkline8-hd">
                                    <div class="main-sparkline8-hd">
                                        <h3>Business modèle</h3>
                                    </div>
                                </div>
                                <div class="sparkline8-graph">
                                    <div class="basic-login-form-ad">                    
                                        <div class="row">
                                            
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="basic-login-inner">                         
                                                        <div class="form-group-inner">
                                                            <label>Qui sont vos clients ? *</label>                
                                                            <textarea required="" class="form-control" name="client" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Quelle est votre proposition de valeur ? *</label>                
                                                            <textarea required="" class="form-control" name="pro_val" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Quels sont vos canaux ?, Moyens de commucation et de distribution que vous mettez en place pour toucher vos clients </label>                
                                                            <textarea class="form-control" name="canaux" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Quelle est votre relation client ? </label>                
                                                            <textarea class="form-control" name="rel_cli" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Quel est votre flux de revenus ?, Toutes les rentrées d'argent généréées par par votre activité </label>                
                                                            <textarea class="form-control" name="flux" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div> 
                                                       
                                                    </div>
                                                </div>

                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="basic-login-inner">
                                                        <div class="form-group-inner">
                                                            <label>Quelles sont vos ressources clés ? </label>                
                                                            <textarea class="form-control" name="res_cle" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Quelles sont vos activités clés ? </label>                
                                                            <textarea class="form-control" name="act_cle" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Quelles sont vos partenaires clés ? </label>                
                                                            <textarea class="form-control" name="part_cle" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div> 

                                                        <div class="form-group-inner">
                                                            <label>Quelle est la structure de vos coûts ? </label>                
                                                            <textarea class="form-control" name="str_cout" rows="5" cols="33">                           
                                                            </textarea>
                                                        </div>
                                                        <div class="form-group-inner">
                                                            <label>Sur une echelle de 1 à 4, à quel point notre appui est décisif pour la réussite de votre initiative entrepreneuriale </label>                
                                                            <select name="echelle" class="form-control">
                                                                <option value="1">1
                                                                    
                                                                </option>
                                                                <option value="2">2
                                                                    
                                                                </option>
                                                                <option value="3">3
                                                                    
                                                                </option>
                                                                <option value="4">4
                                                                    
                                                                </option>
                                                                
                                                            </select>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>De quoi avez vous besoin ? </label>                
                                                            <select name="besoin" class="form-control">
                                                                <option value="Hebergement (locaux)">Hebergement (locaux)
                                                                    
                                                                </option>
                                                                <option value="Accompagnement sur le modèle d'affaire">Accompagnement sur le modèle d'affaire
                                                                    
                                                                </option>
                                                                <option value="Accompagnement sur le la technique">Accompagnement sur le la technique
                                                                    
                                                                </option>
                                                                <option value="Réseau de partenaires ou clients">Réseau de partenaires ou clients
                                                                    
                                                                </option>
                                                                <option value="Financement">Financement
                                                                    
                                                                </option>
                                                                <option value="Partage d'expérience">Partage d'experience
                                                                    
                                                                </option>
                                                                <option value="Autre">Autre
                                                                    
                                                                </option>
                                                                
                                                            </select>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <label>Lien d'une vidéo de 5 minutes dans laquelle vous présentez et defendez votre projet.</label>
                                                            <input type="text" name="video"  class="form-control" placeholder="Ex:youtube/mon_projet" />
                                                        </div>

                                                    </div>
                                                </div>                                            
                                                                
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Part 2 -->


                            
                            <div class="text-center">                                
                                <button type="reset" class="btn btn-default">
                                    Annuler
                                </button>
                                <button type="submit" class="btn btn-success loginbtn">
                                    Soumettre
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
			</div>
            

			<div class="text-center login-footer">
				<p>Copyright © <?=date('Y');?>. Tout droit reservé. Par <a href="https://beoogolab.org" target="blank_">BeoogoLAB</a></p>
			</div>
		</div>   
    </div>


    <!-- jquery
		============================================ -->
    <script src="public/vendor/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="public/vendor/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="public/vendor/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="public/vendor/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="public/vendor/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="public/vendor/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="public/vendor/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="public/vendor/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="public/vendor/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="public/vendor/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="public/vendor/js/metisMenu/metisMenu.min.js"></script>
    <script src="public/vendor/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="public/vendor/js/tab.js"></script>
    <!-- icheck JS
		============================================ -->
    <script src="public/vendor/js/icheck/icheck.min.js"></script>
    <script src="public/vendor/js/icheck/icheck-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="public/vendor/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="public/vendor/js/main.js"></script>    
</body>

</html>