<?php 
	
  include_once '../model/Reservation.class.php';

  if ( isset($_POST['id_reservation']) ) 
  {
  	$client = strip_tags(htmlspecialchars($_POST['client']));
   	$contact = strip_tags(htmlspecialchars($_POST['contact']));
   	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));
   	$debut = strip_tags(htmlspecialchars($_POST['debut']));   	
   	$fin = strip_tags(htmlspecialchars($_POST['fin']));
    $objet = strip_tags(htmlspecialchars($_POST['objet'])); 
    $personne = strip_tags(htmlspecialchars($_POST['personne']));
    $statut = strip_tags(htmlspecialchars($_POST['statut']));
    $espace = strip_tags(htmlspecialchars($_POST['espace']));		
	$id_reservation = $_POST['id_reservation'];

	$data = array(
		'client' => $client,
   		'contact' => $contact,
   		'email' => $email,
   		'debut' => $debut,   		
   		'fin' => $fin,   		
   		'objet' => $objet,
         'personne' => $personne,
         'statut' => $statut,
         'espace' => $espace,
		'id_reservation' => $id_reservation
		);
		  	
  		Reservation::modifier($data);
  		header('Location:../view/index.php?page=reservation');
	
  	
  }
  else
  {
  	echo '
	     <h3 style="color: red">
		 	Impossible de Modifier cette reservation erreur !
		 </h3>
		 <a href="../view/index.php?page=reservation">Retour</a>
		 ';
  }
	

 ?>