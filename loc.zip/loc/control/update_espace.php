<?php 
	
  include_once '../model/Espace.class.php';

  if ( isset($_POST['id_espace']) ) 
  {
  	$intitule = strip_tags(htmlspecialchars($_POST['intitule']));
	$place = strip_tags(htmlspecialchars(trim($_POST['place'])));
	$table = strip_tags(htmlspecialchars(trim($_POST['table'])));
	$description = strip_tags(htmlspecialchars($_POST['description']));		
	$id_espace = $_POST['id_espace'];

	$data = array(
		'intitule' => $intitule,
		'place' => $place,
		'table' => $table,
		'description' => $description,
		'id_espace' => $id_espace
		);
		  	
  		Espace::modifier($data);
  		header('Location:../view/index.php?page=espace');
	
  	
  }
  else
  {
  	echo '
	     <h3 style="color: red">
		 	Impossible de Modifier cet espace erreur !
		 </h3>
		 <a href="../view/index.php?page=espace">Retour</a>
		 ';
  }
	

 ?>