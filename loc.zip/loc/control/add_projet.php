<!DOCTYPE html>
<html>
<head>
  <title>BeoogoLAB - SyLAB | Soumission de Projet</title>
  <meta charset="utf-8">
  <!-- Bootstrap CSS
  ============================================ -->
  <link rel="stylesheet" href="../public/vendor/css/bootstrap.min.css">
  <!-- Sweetalert CSS
  ============================================ -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">

  <!-- jquery
    ============================================ -->
    <script src="../public/vendor/js/vendor/jquery-1.12.4.min.js"></script>
</head>
<body>
  <?php 
   include_once'../model/Projet.class.php';

   if (isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['contact']) ) 
   {
    /*Infos*/
    $civilite = strip_tags(htmlspecialchars($_POST['civilite']));
    $nom = strip_tags(htmlspecialchars($_POST['nom']));
    $prenom = strip_tags(htmlspecialchars($_POST['prenom']));
    $dob = strip_tags(htmlspecialchars($_POST['dob']));
    $pays = strip_tags(htmlspecialchars($_POST['pays_r']));
    $ville = strip_tags(htmlspecialchars($_POST['ville_r']));
    $contact = strip_tags(htmlspecialchars($_POST['contact']));
    $email = strip_tags(htmlspecialchars($_POST['email']));
    $facebook = strip_tags(htmlspecialchars($_POST['fb']));
    $twitter = strip_tags(htmlspecialchars($_POST['tw']));
    $formation_academique = strip_tags(htmlspecialchars($_POST['form_aca']));
    $experience_pro = strip_tags(htmlspecialchars($_POST['exp_pro']));
    $nom_projet = strip_tags(htmlspecialchars($_POST['nom_projet']));
    $present_projet = strip_tags(htmlspecialchars($_POST['pre_projet']));
    $categorie = strip_tags(htmlspecialchars($_POST['cate']));
    $form_juridique = strip_tags(htmlspecialchars($_POST['rccm']));
    $lien_solution = strip_tags(htmlspecialchars($_POST['lien_sol']));
    $avancement = strip_tags(htmlspecialchars($_POST['avancement']));
    $equipe = strip_tags(htmlspecialchars($_POST['team']));
    $incube = strip_tags(htmlspecialchars($_POST['incub']));
    $finance = strip_tags(htmlspecialchars($_POST['finance']));

    /*BMC*/
    $client = strip_tags(htmlspecialchars($_POST['client']));
    $valeur = strip_tags(htmlspecialchars($_POST['pro_val']));
    $canaux = strip_tags(htmlspecialchars($_POST['canaux']));
    $relation = strip_tags(htmlspecialchars($_POST['rel_cli']));
    $flux = strip_tags(htmlspecialchars($_POST['flux']));
    $ressource = strip_tags(htmlspecialchars($_POST['res_cle']));
    $activite = strip_tags(htmlspecialchars($_POST['act_cle']));
    $partenaire = strip_tags(htmlspecialchars($_POST['part_cle']));    
    $cout = strip_tags(htmlspecialchars($_POST['str_cout']));
    $echelle = strip_tags(htmlspecialchars($_POST['echelle']));
    $besoin = strip_tags(htmlspecialchars($_POST['besoin']));
    $video = strip_tags(htmlspecialchars($_POST['video']));


       
    
    $data = array(
      'civilite' => $civilite,
      'nom' => $nom,
      'prenom' => $prenom,
      'dob' => $dob,
      'pays' => $pays,
      'ville' => $ville,
      'contact' => $contact,
      'email' => $email,
      'facebook' => $facebook,
      'twitter' => $twitter,
      'formation_academique' => $formation_academique,
      'experience_pro' => $experience_pro,
      'nom_projet' => $nom_projet,
      'present_projet' => $present_projet,
      'categorie' => $categorie,
      'form_juridique' => $form_juridique,
      'lien_solution' => $lien_solution,
      'avancement' => $avancement,
      'equipe' => $equipe,
      'incube' => $incube,
      'finance' => $finance,

      'client' => $client,
      'valeur' => $valeur,
      'canaux' => $canaux,
      'relation' => $relation,
      'flux' => $flux,
      'ressource' => $ressource,
      'activite' => $activite,
      'partenaire' => $partenaire,      
      'cout' => $cout,
      'echelle' => $echelle,      
      'besoin' => $besoin,
      'video' => $video      
      );

    Projet::register($data);
      $content = 'Bonjour cher '.$data['nom'].', nous vous informons que votre projet a été soumis avec succès au niveau de BeoogoLAB, nous vous reviendrons pour la suite. Cordialement, BeoogoLAB.                 
                ';
      $content = (string)$content;
      $contact = (int)$contact;
      $email = (string)$email;
      try 
      {                  
          Projet::notifier($content, $contact, $email );
      } 
      catch (Exception $e) 
      {
          die();        
              
      }          
                

    echo '
       <a class="btn btn-lg btn-primary" href="https://beoogolab.org">
         Projets soumis, retour sur la page d\'accueil  
       </a>
      <script language="javascript">
        swal("Réussi", "Projet soumis avec succès", "success");        
      </script>';

   }
   else
   {
    echo '
        <a class="btn btn-lg btn-danger" href="https://beoogolab.org">
         Reessayer 
       </a>

      <script language="javascript">
        swal("Erreur", " !!! ", "error");       
      </script>';
   }
 ?>


<!-- jquery
    ============================================ -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
</body>
</html>

