<?php     
    include_once '../model/Espace.class.php';

	if ( isset($_POST['id_espace']) ) 
	{
		Espace::supprimer($_POST['id_espace']);
		header('location:../view/index.php?page=espace');
	}
	else
	{
		echo '
		 <h3 style="color: red">
		 	Impossible de supprimer cet espace !
		 </h3>
		 <a href="../view/index.php?page=espace">Retour</a>

		';
	}

 ?>
