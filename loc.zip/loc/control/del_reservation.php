<?php     
    include_once '../model/Reservation.class.php';

	if ( isset($_POST['id_reservation']) ) 
	{
		Reservation::supprimer($_POST['id_reservation']);
		header('location:../view/index.php?page=reservation');
	}
	else
	{
		echo '
		 <h3 style="color: red">
		 	Impossible de supprimer cette reservation !
		 </h3>
		 <a href="../view/index.php?page=reservation">Retour</a>

		';
	}

 ?>
