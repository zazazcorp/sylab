<?php 
   include_once'../model/Visiteur.class.php';

   if (isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['contact']) ) 
   {
   	$nom = strip_tags(htmlspecialchars($_POST['nom']));
   	$prenom = strip_tags(htmlspecialchars($_POST['prenom']));
   	$contact = strip_tags(htmlspecialchars($_POST['contact']));
   	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));   	
   	$profession = strip_tags(htmlspecialchars($_POST['profession']));
      $structure = strip_tags(htmlspecialchars($_POST['structure']));   	
   	

   	$data = array(
   		'nom' => $nom,
   		'prenom' => $prenom,
   		'contact' => $contact,
   		'email' => $email,   		
   		'profession' => $profession,   		
   		'structure' => $structure
      );

   	Visiteur::register($data);

   	echo '
		    <script language="javascript">
				swal("Réussi", "Visiteur ajouté avec succès", "success");				
			</script>';

   }
   else
   {
   	echo '
		    <script language="javascript">
				swal("Erreur", " !!! ", "error");				
			</script>';
   }





 ?>