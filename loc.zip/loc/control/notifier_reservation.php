<?php 

	include_once'../model/Reservation.class.php';
	if (isset($_POST['content']) AND isset($_POST['contact']) AND isset($_POST['email'])) 
	{
		$content = (string)$_POST['content'];
		$contact = (int)$_POST['contact'];
		$email = (string)$_POST['email'];
		Reservation::notifier($content, $contact, $email);
		header('Location:../view/index.php?page=reservation');
	}

 ?>