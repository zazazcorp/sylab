<?php 

include_once "../model/User.class.php";
include_once "../API/CodeOtp.class.php";


if (isset($_POST['number']) AND isset($_POST['password'])) 
{
	$number= intval(strip_tags(htmlspecialchars(trim($_POST['number'])))) ;
    $password=$_POST['password'];

    if ($number != 0) 
    {
    	$confirm = User::login($number, $password);
    	if ($confirm != 'NO') 
    	{
    		$otp = new CodeOtp($number);
    		$otp->sendOtp();
    		User::insertOtp($otp->getOtp(), $confirm[0]->id_user);
    		session_start();
    		$_SESSION['id'] = $confirm[0]->id_user;
    		$_SESSION['number'] = $confirm[0]->contact;

    		echo '
    		    <script language="javascript">
					window.location.href = "login_otp.php";
				</script>';


    	}
    	else
    	{
    		echo '
		     <script type="text/javascript">
		         swal("Erreur!", "Echec veuillez reessayer !", "error");
		    </script>';
    	}
    }
    else
    {
    	echo '
	     <script type="text/javascript">
	         swal("Erreur!", "Veuillez saisir des chiffres !", "error");
	    </script>';
    }
   
}
else
{
	echo '
     <script type="text/javascript">
         swal("Erreur!", "Veuillez remplir les champs !", "error");
    </script>';
}



/*

if(isset($_POST['login']) AND isset($_POST['password']))
	{
            $login=strip_tags(htmlspecialchars($_POST['login']));
            $password=$_POST['password'];

            if(filter_var($email, FILTER_VALIDATE_EMAIL))
			{                
                if($connect=connexpdo('myparam'))
				{
                    // Preparation et execution de la requete 
                    $requete="SELECT * FROM membre WHERE email=?";
                    $user=$connect->prepare($requete);
                    $user->execute(array($email));
                    $nombre=$user->rowcount();
                    // Verification
                    if($nombre==1)
					{
                        $data=$user->fetch();

                        if(password_verify($password, $data['mot_de_passe']))
						{
                            $json[]=$data['type'];
                            $_SESSION['id']=$data['id'];
                            $_SESSION['nom']=$data['nom'];
                            $_SESSION['prenom']=$data['prenom'];
                            $_SESSION['type']=$data['type'];
                            $_SESSION['avatar']=$data['avatar'];
                            $_SESSION['sexe']=$data['sexe'];

							$_SESSION['numeroprojet']=$data['numeroprojet'];
							
                        $user->closeCursor();
                        $connect=null;
                        echo json_encode($json);
                        }

                        else
						{
                            $connect=null;
                            $json[]= 1;
                            echo json_encode($json);
                        }

                    }
                    else
					{
                        $reqgerant="SELECT * FROM gerant WHERE email=?";
                        $gerant=$connect->prepare($reqgerant);
                        $gerant->execute(array($email));
                        $nbr=$gerant->rowcount();
                                if($nbr==1){

                                    $data=$gerant->fetch();
                                if(password_verify($password, $data['mot_de_passe']))
								{
                                    
                                    $json[]=$data['type'];
                                    $_SESSION['id']=$data['id'];
                                    $_SESSION['nom']=$data['nom'];
                                    $_SESSION['prenom']=$data['prenom'];
                                    $_SESSION['type']=$data['type'];
                                    $_SESSION['avatar']=$data['avatar'];
                                    $_SESSION['sexe']=$data['sexe'];

                                    $gerant->closeCursor();
                                    $connect=null;
                                    echo json_encode($json);
                                }

                                else
								{
                                    $connect=null;
                                    $json[]= 1;
                                    echo json_encode($json);
                                }

                                }

                                else
								{
                                    $json[]="inexistant";

                                    $connect=null;
                                    echo json_encode($json);
                                }
                    }                
                }
                else
                {
                    $json[]=1;

                    $connect=null;
                    echo json_encode($json);
                    
                }

            }

            else
			{
                $json[]=2;

                $connect=null;
                echo json_encode($json);
            }            
    }



echo '
     <script type="text/javascript">
         swal("Cool!", "Voici vos infos  :  ", "success");
    </script>
';

*/

//echo $login2;



 ?>