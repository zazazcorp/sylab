<?php 
	
  include_once '../model/User.class.php';

  if ( isset($_POST['id_user']) ) 
  {
  	$nom = strip_tags(htmlspecialchars(trim($_POST['nom'])));
	$prenom = strip_tags(htmlspecialchars(trim($_POST['prenom'])));
	$contact = strip_tags(htmlspecialchars(trim($_POST['number'])));
	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));
	$droit = strip_tags(htmlspecialchars(trim($_POST['droit'])));
	$statut = strip_tags(htmlspecialchars(trim($_POST['statut'])));
	$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
	$id_user = $_POST['id_user'];

	$data = array(
		'nom' => $nom,
		'prenom' => $prenom,
		'contact' => $contact,
		'email' => $email,
		'droit' => $droit,
		'statut' => $statut,
		'password' => $password,
		'id_user' => $id_user);

  	if (!empty($_POST['password'])) 
  	{
  		if ($_POST['password'] == $_POST['rpassword']) 
  		{
  			User::modifier($data);
  			header('Location:../view/index.php?page=gerant');
  		}
  		else
  		{
           echo '
		     <h3 style="color: red">
			 	Impossible de Modifier l\'utilisateur, les mots de passe ne correspondent pas !
			 </h3>
			 <a href="../view/index.php?page=gerant">Retour</a>
		 ';
  		}

				
  	}
  	else
  	{
  		User::modifier_sans_pwd($data);
  		header('Location:../view/index.php?page=gerant');
  	}

  	
  }
  else
  {
  	echo '
	     <h3 style="color: red">
		 	Impossible de Modifier l\'utilisateur erreur !
		 </h3>
		 <a href="../view/index.php?page=gerant">Retour</a>
		 ';
  }
	

 ?>