<?php 
   include_once'../model/Espace.class.php';

   if (isset($_POST['intitule']) AND isset($_POST['place']) AND isset($_POST['table']) ) 
   {
   	$intitule = strip_tags(htmlspecialchars($_POST['intitule']));
   	$place = strip_tags(htmlspecialchars($_POST['place']));
   	$table = strip_tags(htmlspecialchars($_POST['table']));
   	$description = strip_tags(htmlspecialchars($_POST['description'])); 	   	
   	

   	$data = array(
   		'intitule' => $intitule,
   		'place' => $place,
   		'table' => $table,
   		'description' => $description
      );

   	Espace::register($data);

   	echo '
		    <script language="javascript">
				swal("Réussi", "Espace ajouté avec succès", "success");				
			</script>';

   }
   else
   {
   	echo '
		    <script language="javascript">
				swal("Erreur", " !!! ", "error");				
			</script>';
   }





 ?>