<?php 
	
  include_once '../model/Visiteur.class.php';

  if ( isset($_POST['id_visiteur']) ) 
  {
  	$nom = strip_tags(htmlspecialchars(trim($_POST['nom'])));
	$prenom = strip_tags(htmlspecialchars(trim($_POST['prenom'])));
	$contact = strip_tags(htmlspecialchars(trim($_POST['contact'])));
	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));
	$profession = strip_tags(htmlspecialchars(trim($_POST['profession'])));
	$structure = strip_tags(htmlspecialchars(trim($_POST['structure'])));	
	$id_visiteur = $_POST['id_visiteur'];

	$data = array(
		'nom' => $nom,
		'prenom' => $prenom,
		'contact' => $contact,
		'email' => $email,
		'profession' => $profession,
		'structure' => $structure,		
		'id_visiteur' => $id_visiteur);

  	
  		Visiteur::modifier($data);
  		header('Location:../view/index.php?page=visiteur');
  	
  }
  else
  {
  	echo '
	     <h3 style="color: red">
		 	Impossible de Modifier le visiteur erreur !
		 </h3>
		 <a href="../view/index.php?page=gerant">Retour</a>
		 ';
  }
	

 ?>