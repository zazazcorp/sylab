<?php 
session_start();

include_once "../model/User.class.php";


if (isset($_POST['otp']) AND !empty($_POST['otp'])) 
{
	$otp = strip_tags(htmlspecialchars(trim($_POST['otp'])));
	$confirm = User::loginOtp($otp);

	if ($confirm != 'NO') 
	{
		$_SESSION['nom'] = $confirm[0]->nom;
    	$_SESSION['prenom'] = $confirm[0]->prenom;
    	$_SESSION['email'] = $confirm[0]->email;
    	$_SESSION['droit'] = $confirm[0]->droit;
    	$_SESSION['statut'] = $confirm[0]->statut;

    		echo '
    		    <script language="javascript">
					window.location.href = "index.php";
				</script>'; 
				
	}
	else
	{
		echo '
	     <script type="text/javascript">	         
	         swal("Erreur!","Code incorrect !", "error");
	     </script>';
	}


}
else
{
	echo '
     <script type="text/javascript">
         swal("Erreur!", "Veuillez remplir le champ !", "error");
    </script>';
}






 ?>