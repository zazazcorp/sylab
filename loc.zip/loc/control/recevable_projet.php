<?php 
	include_once'../model/Projet.class.php';

	if (isset($_POST['id_projet'])) 
	{
		$data = array(
			'statut' => 'recevable',
			'id_projet' => $_POST['id_projet']
		       );
		Projet::modifierStatut($data);

		header('Location:../view/index.php?page=inbox');
	}
	else
	{
		//header('Location:../view/index.php?page=inbox');
		echo "Erreur".$_POST['id_projet'];		
	}

 ?>