<?php 
session_start();
include_once "../model/User.class.php";

User::logout($_SESSION['id']);

header('location:../view/login.php');

 ?>