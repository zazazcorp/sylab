<?php 
   include_once'../model/User.class.php';

   if (isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['number']) ) 
   {
   	$nom = strip_tags(htmlspecialchars(trim($_POST['nom'])));
   	$prenom = strip_tags(htmlspecialchars($_POST['prenom']));
   	$number = strip_tags(htmlspecialchars(trim($_POST['number'])));
   	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));   	
   	$droit = strip_tags(htmlspecialchars(trim($_POST['droit'])));   	
   	$pwd = password_hash($_POST['password'], PASSWORD_BCRYPT);
      $statut = strip_tags(htmlspecialchars(trim($_POST['statut'])));

   	$data = array(
   		'nom' => $nom,
   		'prenom' => $prenom,
   		'number' => $number,
   		'email' => $email,   		
   		'droit' => $droit,   		
   		'pwd' => $pwd,
         'statut' => $statut
      );

   	User::register($data);

   	echo '
		    <script language="javascript">
				swal("Réussi", "Gérant ajouté avec succès", "success");				
			</script>';

   }
   else
   {
   	echo '
		    <script language="javascript">
				swal("Erreur", " !!! ", "error");				
			</script>';
   }





 ?>