<?php 
   include_once'../model/Reservation.class.php';

   if (isset($_POST['client']) AND isset($_POST['contact']) AND isset($_POST['email']) ) 
   {
   	$client = strip_tags(htmlspecialchars($_POST['client']));
   	$contact = strip_tags(htmlspecialchars($_POST['contact']));
   	$email = strip_tags(htmlspecialchars(trim($_POST['email'])));
   	$debut = strip_tags(htmlspecialchars($_POST['debut']));   	
   	$fin = strip_tags(htmlspecialchars($_POST['fin']));
    $objet = strip_tags(htmlspecialchars($_POST['objet'])); 
    $personne = strip_tags(htmlspecialchars($_POST['personne']));
    $statut = strip_tags(htmlspecialchars($_POST['statut']));
    $espace = strip_tags(htmlspecialchars($_POST['espace']));  	
   	
   	$data = array(
   		'client' => $client,
   		'contact' => $contact,
   		'email' => $email,
   		'debut' => $debut,   		
   		'fin' => $fin,   		
   		'objet' => $objet,
         'personne' => $personne,
         'statut' => $statut,
         'espace' => $espace
      );

   	Reservation::register($data);
      $content = 'Bonjour cher '.$data['client'].', nous, BeoogoLAB venons par ce présent vous informer que votre réservation a été soumise. Nous vous contacterons pour la suite. Cordialement, BeoogoLAB.                 
                ';
      $content = (string)$content;
      $contact = (int)$contact;
      $email = (string)$email;          
      Reservation::notifier($content, $contact, $email );          

   	echo '
		    <script language="javascript">
				swal("Réussi", "Reservation ajouté avec succès", "success");				
			</script>';

   }
   else
   {
   	echo '
		    <script language="javascript">
				swal("Erreur", " !!! ", "error");				
			</script>';
   }





 ?>