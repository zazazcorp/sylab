<?php

include_once "Model.class.php";

/**
 * Classe  User. 
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class User extends Model
 {

    /**
     * Fonction static login
     * @param int,string : $number,$password
     */
    public static function login($number, $password)
    {
        $con = parent::getPDO();
        
        $us = $con->prepare('SELECT * FROM user 
                              WHERE contact=?
                              AND statut="actif" '); 
        $us->execute(array($number));                                
        $data = $us->fetchAll(PDO::FETCH_CLASS, 'User');

        if (!empty($data) ) 
        {
            if (password_verify($password, $data[0]->password)) 
            {
                return $data;
            }
            else
            {
                return 'NO';
            }
            
        }
        else
        {
            return 'NO';
        }       
        
    }
    

    /**
     * Fonction static logout
     * @param int, $user_id
     */
    public static function logout($user_id)
    {
        session_destroy();

    }

    /**
     * Fonction static ajouter one row
     * @param array, $_POST
     */
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO user VALUES(?,?,?,?,?,?,?,?,?)');
        $ins->execute(array(NULL, $data['nom'], $data['prenom'], $data['number'], 
            $data['email'], $data['droit'], $data['pwd'], NULL, $data['statut'] ));
    }

    /**
     * Fonction static Afficher all row
     * @return array, $donne
     */
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM user ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'User');

        return $donne;        
    }
    
    /**
     * Fonction static afficher one row
     * @param int, $id
     */
    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM user WHERE id_user="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'User');

        return $donne;        
    }

    public static function insertOtp($otp, $Id)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE user SET code_otp=? WHERE id_user=?');
        $ins->execute(array($otp, $Id));

    }


    /**
     * Fonction static login otp
     * @param int, $otp
     */
    public static function loginOtp($otp)
    {
        $con = parent::getPDO();
        
        $us = $con->prepare('SELECT * FROM user 
                              WHERE code_otp=?'); 
        $us->execute(array($otp));                                
        $data = $us->fetchAll(PDO::FETCH_CLASS, 'User');
        if (!empty($data)) 
        {
            return $data;
        }
        else
        {
            return 'NO';
        }


    }

    /**
     * Fonction static Modification all row
     * @param array, $_POST
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE user 
                              SET nom=?, prenom=?, contact=?, email=?,
                              droit=?, password=?, statut=? 
                              WHERE id_user=?');
        $ins->execute(array($data['nom'], $data['prenom'], $data['contact'],
                            $data['email'], $data['droit'], $data['password'],
                            $data['statut'], $data['id_user'] ));
    }

    /**
     * Fonction static Modification sans mot de passe
     * @param array, $_POST
     */
    public static function modifier_sans_pwd($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE user 
                              SET nom=?, prenom=?, contact=?, email=?,
                              droit=?, statut=? 
                              WHERE id_user=?');
        $ins->execute(array($data['nom'], $data['prenom'], $data['contact'],
                            $data['email'], $data['droit'], $data['statut'], 
                            $data['id_user'] ));
    }


    /**
     * Fonction static supprimer one row
     * @param int, $id
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM user WHERE id_user=?');
        $sup->execute(array($id));
        
        
    }

 }