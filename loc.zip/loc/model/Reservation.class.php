<?php

include_once "Model.class.php";

/**
 * Classe  Visiteur. 
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class Reservation extends Model
 {
   
    /**
     * Fonction static Ajouter one row
     * @param array, $data
     */ 
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO reservation VALUES(?,?,?,?,?,?,?,?,?,?)');
        $ins->execute(array(NULL, $data['client'], $data['contact'], $data['email'], 
                            $data['debut'], $data['fin'], $data['objet'], $data['personne'],
                            $data['statut'], $data['espace'] ));
    }

    /**
     * Fonction static Afficher all row
     * @return array $donne
     */
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM reservation ORDER BY client');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Reservation');

        return $donne;        
    }

    /**
     * Fonction static Afficher one row
     * @return array $donne
     */
    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM reservation WHERE id_reservation="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Reservation');

        return $donne;        
    }

    /**
     * Fonction static compte les rerservations en cours
     * @return array $donne
     */
    public static function countAll()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_reservation) AS total FROM reservation ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Reservation');

        return $donne;        
    }     

    /**
     * Fonction static Modification all row
     * @param array
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE reservation 
                              SET client=?, contact=?, email=?, debut=?, fin=?, objet=?,
                              personne=?, statut=?, espace=?
                              WHERE id_reservation=?');
        var_dump($ins);
        $ins->execute(array($data['client'], $data['contact'], $data['email'], 
                            $data['debut'], $data['fin'], $data['objet'], $data['personne'],
                            $data['statut'], $data['espace'], $data['id_reservation'] ));
    }

    /**
     * Fonction static Supprimer one row
     * @param int, $id == id_user to delete
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM reservation WHERE id_reservation=?');
        $sup->execute(array($id));        
        
    }

    /**
     * Fonction static Notifier one row
     * @param string, $content == content notification
     * @param int , $contact == number nofifier
     */
    public static function notifier($content, $contact, $email)
    {
        $content_sms = urlencode($content);
        $contact = (int)$contact;       
        $url = "http://79.143.188.122:1401/send?username=ticanalyse&password=25az35&from=3424&to=226".$contact."&content=".$content_sms;

        /*SMS*/
        try 
        {
           file_get_contents($url); 
        } 
        catch (Exception $e) 
        {
            die();
        }
        

        /*Email*/
        try 
        {
            $to = $email;  
            $email_subject = "BeoogoLAB | Reservation ";
            $email_body = $content;
            $headers = "From: noreply@beoogolab.org\n"; 
            $headers .= "Reply-To: info@beoogolab.org"; 

            mail($to,$email_subject,$email_body,$headers);
            
        } 
        catch (Exception $e) 
        {
            die();
        }
             
        
    }

 }