<?php

include_once "Model.class.php";

/**
 * Classe  Visiteur. 
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class Visiteur extends Model
 {
   
    /**
     * Fonction static Ajouter one row
     * @param array, $data
     */ 
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO visiteur VALUES(?,?,?,?,?,?,?,?)');
        $ins->execute(array(NULL, $data['nom'], $data['prenom'], $data['email'], 
            $data['contact'], $data['profession'], $data['structure'],
            date('Y-m-d H:i:s')  ));
    }

    /**
     * Fonction static Afficher all row
     * @return array $donne
     */
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM visiteur ORDER BY nom,prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Visiteur');

        return $donne;        
    }     

    /**
     * Fonction static Modification all row
     * @param array
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE visiteur 
                              SET nom=?, prenom=?, email=?, contact=?,
                              profession=?, structure=? 
                              WHERE id_visiteur=?');
        $ins->execute(array($data['nom'], $data['prenom'], $data['email'],
                            $data['contact'], $data['profession'], $data['structure'], $data['id_visiteur'] ));
    }


    /**
     * Fonction static compte les visiteurs all
     * @return array $donne
     */
    public static function countAll()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_visiteur) AS total FROM visiteur ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Visiteur');

        return $donne;        
    }

    /**
     * Fonction static Supprimer one row
     * @param int, $id == id_user to delete
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM visiteur WHERE id_visiteur=?');
        $sup->execute(array($id));
        
        
    }

 }