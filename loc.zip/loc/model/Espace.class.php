<?php

include_once "Model.class.php";

/**
 * Classe  Visiteur. 
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class Espace extends Model
 {
   
    /**
     * Fonction static Ajouter one row
     * @param array, $data
     */ 
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO espace VALUES(?,?,?,?,?)');
        $ins->execute(array(NULL, $data['intitule'], $data['place'], $data['table'], 
            $data['description'] ));
    }

    /**
     * Fonction static Afficher all row
     * @return array $donne
     */
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM espace ORDER BY intitule');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Espace');

        return $donne;        
    }


    /**
     * Fonction static Afficher one row
     * @return array $donne
     */
    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM espace WHERE id_espace="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Espace');

        return $donne;        
    }

    /**
     * Fonction static compte les espaces disponibles
     * @return array $donne
     */
    public static function countAll()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_espace) AS total FROM espace ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Espace');

        return $donne;        
    }     

    /**
     * Fonction static Modification all row
     * @param array
     */
    public static function modifier($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE espace 
                              SET intitule=?, place=?, nb_table=?, description=?
                              WHERE id_espace=?');
        var_dump($ins);
        $ins->execute(array($data['intitule'], $data['place'], $data['table'],
                            $data['description'], $data['id_espace'] ));
    }

    /**
     * Fonction static Supprimer one row
     * @param int, $id == id_user to delete
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM reservation WHERE espace=?');
        $sup->execute(array($id));

        $sup = $con->prepare('DELETE FROM espace WHERE id_espace=?');
        $sup->execute(array($id));
        
        
    }

 }