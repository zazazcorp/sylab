<?php 

$has = password_hash('zcorp', PASSWORD_DEFAULT);
echo 'zcorp ==>'.$has;
echo '<br/>';
echo 'Separateur';
echo '<br/>';
echo password_verify('zcorp', $has);



 ?>