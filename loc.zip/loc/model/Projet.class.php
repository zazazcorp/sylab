<?php

include_once "Model.class.php";

/**
 * Classe  Visiteur. 
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class Projet extends Model
 {
   
    /**
     * Fonction static Ajouter one row
     * @param array, $data
     */ 
    public static function register($data)
    {
        $con = parent::getPDO();
        $ins = $con->prepare('INSERT INTO projet 
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');

        $ins->execute(array(NULL,NULL,date('Y-m-d H:i:s'), 
                            $data['civilite'], $data['nom'], $data['prenom'], 
                            $data['dob'], $data['pays'], $data['ville'], $data['contact'],
                            $data['email'], $data['facebook'], $data['twitter'],
                            $data['formation_academique'], $data['experience_pro'],
                            $data['nom_projet'], $data['present_projet'], $data['categorie'],
                            $data['form_juridique'], $data['lien_solution'], $data['avancement'],
                            $data['equipe'], $data['incube'], $data['finance'], $data['client'],
                            $data['valeur'], $data['canaux'], $data['relation'], $data['flux'],
                            $data['ressource'], $data['activite'], $data['partenaire'],
                            $data['cout'], $data['echelle'], $data['besoin'], $data['video']
                           ) 
                      );
    }

    /**
     * Fonction static Afficher all row
     * @return array $donne
     */
    public static function afficher()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet ORDER BY nom, prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static Afficher all row Inbox
     * @return array $donne
     */
    public static function afficherInbox()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet WHERE statut IS NULL ORDER BY nom, prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static Afficher all row Archive
     * @return array $donne
     */
    public static function afficherArchive()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet WHERE statut="archive" ORDER BY nom, prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static Afficher all row Racevable
     * @return array $donne
     */
    public static function afficherRecevable()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet WHERE statut="recevable" ORDER BY nom, prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static Afficher all row accepte
     * @return array $donne
     */
    public static function afficherAccepte()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet WHERE statut="accepte" ORDER BY nom, prenom');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static Afficher one row
     * @return array $donne
     */
    public static function afficherOne($id)
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT * FROM projet WHERE id_projet="'.$id.'"');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static compte les Projets en inbox
     * @return array $donne
     */
    public static function countInbox()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_projet) AS inbox FROM projet WHERE statut IS NULL ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static compte les Projets Archivés
     * @return array $donne
     */
    public static function countArchive()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_projet) AS archive FROM projet WHERE statut="archive" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }

    /**
     * Fonction static compte les Projets Accepte
     * @return array $donne
     */
    public static function countAccepte()
    {
        $con = parent::getPDO();        
        $ins = $con->query('SELECT COUNT(id_projet) AS accepte FROM projet WHERE statut="accepte" ');          
        $donne = $ins->fetchAll(PDO::FETCH_CLASS, 'Projet');

        return $donne;        
    }     

    /**
     * Fonction static Modification all row
     * @param array
     */
    public static function modifierStatut($data = array())
    {
        $con = parent::getPDO();
        $ins = $con->prepare('UPDATE projet 
                              SET statut=?
                              WHERE id_projet=?');
        var_dump($ins);
        $ins->execute(array($data['statut'], $data['id_projet'] ));
    }

    /**
     * Fonction static Supprimer one row
     * @param int, $id == id_user to delete
     */
    public static function supprimer($id)
    {
        $con = parent::getPDO();
        
        $sup = $con->prepare('DELETE FROM projet WHERE id_projet=?');
        $sup->execute(array($id));        
        
    }

    /**
     * Fonction static Notifier one row
     * @param string, $content == content notification
     * @param int , $contact == number nofifier
     */
    public static function notifier($content, $contact, $email)
    {
        $content_sms = urlencode($content);
        $contact = (int)$contact;        
        $url = "http://79.143.188.122:1401/send?username=ticanalyse&password=25az35&from=3424&to=226".$contact."&content=".$content_sms;

        /*SMS*/
        try 
        {
           file_get_contents($url); 
        } 
        catch (Exception $e) 
        {
            die();
        }
        

        /*Email*/
        try 
        {
            $to = $email;  
            $email_subject = "BeoogoLAB | Projet ";
            $email_body = $content;
            $headers = "From: noreply@beoogolab.org\n"; 
            $headers .= "Reply-To: info@beoogolab.org"; 

            mail($to,$email_subject,$email_body,$headers);
            
        } 
        catch (Exception $e) 
        {
            die();
        }
             
        
    }

 }