<?php

/**
 * Classe  Model.
 * Super Classe pour tous les models.
 * Utilise PDO comme PHP Data Object
 *
 * @version 1.0
 * @author BeoogoLAB
 */

 class Model
 {

    /*Florentin Infos to connect
    5.189.147.111
    /var/www/html/sylab
    DATABASE
    https://sylab.beoogolab.org/phpmyadmin/
    root
    02097787
    sylabdb

    */

    /** 
     *@var array()
     * le tableau dans lequel vont se greffer les données de config de la base de données
     */
    public static $data = array(
            'DB_HOST'=> 'localhost',
            'DB_NAME'=> 'bd_sylab_dev', //online ==> sylabdb
            'DB_USER'=> 'root',
            'DB_PASSWORD'=>'', // online ==> 02097787      
            'DB_PORT'=>'',
            'DB_PREFIX'=>'',
            'DB_DSN'=> 'mysql:host=localhost;dbname=bd_sylab_dev'
                        );

    public static $pdo;

    /** 
     * @return PDO object 
     */
    public static function getPDO()
    {
        /* 
         * Verification si l'objet PDO est pas encore appelé 
         */
        if (self::$pdo === null)
        {
            $con = new PDO(
                self::$data['DB_DSN'],
                self::$data['DB_USER'],
                self::$data['DB_PASSWORD'],
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );

            self::$pdo = $con;

        }

        return self::$pdo;

    } 

 }