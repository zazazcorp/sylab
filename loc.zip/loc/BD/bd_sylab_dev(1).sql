-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 21 Octobre 2019 à 10:26
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `bd_sylab_dev`
--

-- --------------------------------------------------------

--
-- Structure de la table `espace`
--

CREATE TABLE IF NOT EXISTS `espace` (
  `id_espace` int(10) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(100) DEFAULT NULL,
  `place` int(10) DEFAULT NULL,
  `nb_table` int(10) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id_espace`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `espace`
--

INSERT INTO `espace` (`id_espace`, `intitule`, `place`, `nb_table`, `description`) VALUES
(3, 'Espace BangrÃ©', 29, 12, 'Ecran et Wiifi, ClimatisÃ©'),
(4, 'Salle Polyvalente', 100, 13, 'Salle de Coworking, Wiifi, Projecteur'),
(5, 'Coworking', 100, 12, 'Projecteur, AccÃ¨s Wiifi, Climatisation, Balcon, CafÃ©.'),
(6, 'BibliothÃ¨que', 20, 7, 'Projecteur, AccÃ¨s Wiifi, Climatisation, Balcon, CafÃ©.');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE IF NOT EXISTS `projet` (
  `id_projet` int(10) NOT NULL AUTO_INCREMENT,
  `statut` varchar(50) DEFAULT NULL,
  `date_soumi` datetime DEFAULT NULL,
  `civilite` varchar(10) DEFAULT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pays` varchar(100) DEFAULT NULL,
  `ville` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `form_aca` text,
  `exp_pro` text,
  `nom_projet` varchar(255) DEFAULT NULL,
  `pres_pro` text,
  `categorie` varchar(100) DEFAULT NULL,
  `form_juri` varchar(100) DEFAULT NULL,
  `lien_sol` varbinary(255) DEFAULT NULL,
  `avancement` varchar(255) DEFAULT NULL,
  `equipe` text,
  `incube` varchar(255) DEFAULT NULL,
  `finance` varchar(255) DEFAULT NULL,
  `client` text,
  `valeur` text,
  `canaux` text,
  `relation` text,
  `flux` text,
  `ressource` text,
  `activite` text,
  `partenaire` text,
  `cout` text,
  `echelle` int(2) DEFAULT NULL,
  `besoin` varchar(50) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_projet`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `projet`
--

INSERT INTO `projet` (`id_projet`, `statut`, `date_soumi`, `civilite`, `nom`, `prenom`, `dob`, `pays`, `ville`, `contact`, `email`, `facebook`, `twitter`, `form_aca`, `exp_pro`, `nom_projet`, `pres_pro`, `categorie`, `form_juri`, `lien_sol`, `avancement`, `equipe`, `incube`, `finance`, `client`, `valeur`, `canaux`, `relation`, `flux`, `ressource`, `activite`, `partenaire`, `cout`, `echelle`, `besoin`, `video`) VALUES
(1, NULL, NULL, 'M.', 'OUEDRAOGO', 'MARTINE', '1999-03-12', 'Burkina Faso', 'Ouagadougou', '71328582', 'issouf.zcorp.zanne@gmail.com', 'facebook.com/zcorp', 'twitter.com/zcorp', 'Licence', 'Travailleur privÃ©                           \r\n                                                            ', 'ZCORPORATION', 'La Zcorporation est une entreprise de high tech                                            ', 'Solution digitale pour entreprise', 'S.A.S.', 'zcorp.com', 'LancÃ© et en pleine croissance', 'ZANNE Issouf , 10/20/1999, Marketeur\r\nOUEDRAOGO MARTINE, 12/03/1999, CEO        ', 'NON               ', 'NON                       ', 'VIEUX', 'Donne', 'Internezt', 'Bien', '30000', 'Cerveau                        ', 'Programming                           \r\n                                                            ', 'Facebook, Microsoft                           \r\n                                                            ', 'Logiciel 200000                           \r\n                                                            ', 4, 'Hebergement (locaux)', 'youtube.com/zcorp'),
(2, NULL, '2019-10-21 10:22:16', 'M.', 'SARE', 'KARIM', '2000-09-12', 'Burkina Faso', 'KOUDOUGOU', '71328582', 'issouf.zcorp.zanne@gmail.com', 'facebook.com/zcorp', 'twitter.com/zcorp', 'DOCTORAT EN GESTION EN EAU', 'Travailleur du public', 'Faso Marcket Facile', 'Faso Marcket est une idÃ©e de genie', 'E-commerce', 'S.A.R.L.', 'fmf.bf', 'DÃ©jÃ  lancÃ©', 'KABORE NATA, 10/20/1999, Marketeur\r\nOUEDRAOGO Issouf, 12/03/1999, CEO        ', 'NON           ', 'NON                       ', 'Jeunes agÃ©s de 18 Ã  50 ans', 'Vente en ligne et livraison', 'Internet', 'Abonnement', '30000', 'Cerveau                        ', 'Programming                           \r\n                                                            ', 'Facebook, Microsoft                           \r\n                                                            ', 'Logiciel 200000                           \r\n                                                            ', 3, 'Accompagnement sur le la technique', 'youtube.com/zcorp');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `id_reservation` int(10) NOT NULL AUTO_INCREMENT,
  `client` varchar(255) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `objet` text,
  `personne` int(10) DEFAULT NULL,
  `statut` varchar(50) DEFAULT NULL,
  `espace` int(10) NOT NULL,
  PRIMARY KEY (`id_reservation`),
  KEY `espace` (`espace`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `reservation`
--

INSERT INTO `reservation` (`id_reservation`, `client`, `contact`, `email`, `debut`, `fin`, `objet`, `personne`, `statut`, `espace`) VALUES
(2, 'KABORE ALICE PAPE', '71328584', 'issouf.zcorp.zanne@gmail.com', '2019-10-02', '2019-10-31', 'Travail en groupe', 7, 'annule', 6),
(3, 'NANA DRISSA', '67025224', 'issa@gmail.com', '2019-10-16', '2019-10-25', 'Coworking', 4, 'paye', 5),
(4, 'DIALLO HASSAN', '67452312', 'dao@gmail.com', '2019-09-30', '2019-10-23', 'BibliothÃ¨que', 2, 'non paye', 6);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `droit` varchar(30) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `code_otp` int(10) DEFAULT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'inactif',
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `contact` (`contact`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id_user`, `nom`, `prenom`, `contact`, `email`, `droit`, `password`, `code_otp`, `statut`) VALUES
(1, 'ZANNE', 'Issouf', '67025224', 'zissouf@beoogolab.org', 'super_admin', '$2y$10$WXtAhq0Km/.L.fDV9u3lCe0tfN1l.KKMU2HYDCcBbAy5pTWnWcI8W', 291504, 'actif'),
(4, 'GUELBEOGO', 'Elkana', '78765432', 'gelkana@beoogolab.org', 'coach', '$2y$10$KdRlx5L0Aewun9HmO4VokuMrrNBGYnA5mFsnAiCaCoisOOc8oC5lS', NULL, 'inactif');

-- --------------------------------------------------------

--
-- Structure de la table `visiteur`
--

CREATE TABLE IF NOT EXISTS `visiteur` (
  `id_visiteur` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `structure` varchar(255) DEFAULT NULL,
  `date_visite` datetime DEFAULT NULL,
  PRIMARY KEY (`id_visiteur`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `visiteur`
--

INSERT INTO `visiteur` (`id_visiteur`, `nom`, `prenom`, `email`, `contact`, `profession`, `structure`, `date_visite`) VALUES
(1, 'KERE', 'Madina Priscaline', 'km@gmail.com', '78543212', 'Etudiante', 'U-AUBEN', '2019-10-17 15:22:07'),
(2, 'NANA', 'Drissa', 'nana@yhoo.fr', '90876543', 'Professeur', 'C.E.G', '2019-10-15 07:14:27'),
(3, 'KABORE', 'Florentin', 'flo@gmail.com', '45234567', 'Admin', 'BeoogoLAB', '2019-10-17 14:02:56'),
(4, 'OUEDRAOGO', 'MADELEINE', 'omadelaine@gmail.com', '71343536', 'InfirmiÃ¨re', 'Yalgado', '2019-10-20 12:31:07');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `fk_re` FOREIGN KEY (`espace`) REFERENCES `espace` (`id_espace`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
