﻿<!-- 
-- Système Intégré de Gestion (ERP) , gestion antière de BeoogoLAB 
-- Développé par BeoogoLAB
-- Dénomination SyLAB [ Système de gestion de LAB ]
-- Date Juin 2019
-- Version 3.1
-- Author BeoogoLAB
-- Notifications ==== Audit Trail Action à la base de donnée
-- Visiteurs, envoies de messages.
-->