<?php 

/*API , sending sms for login control */


/**
 * Classe  CodeOtp.
 * Build otp pine for users
 * 
 *
 * @version 1.0
 * @author BeoogoLAB
 * 
 */


/*======= API 1 SEND SMS API =====*/


class CodeOtp
{
	private $number;	
	private $otp;

	/**
	 * @param $number(int) ==> Phone Number user 
	*/
	public function __construct($log)
	{
		$this->number = $log;		
	}	

	/**
	 * @param int(otp)
	*/
	private function setOtp($val)
	{
		$this->otp = $val;
	}

	/**
	 * @return the opt code generated 
	*/

	public function getOtp()
	{
		return $this->otp;
	}


	/**
	 * Generate pine code size 6
	 * @return integer size 6 ==> pine code
	*/
	private function GeneratePine()
	{
		$numb = "1234567890";
		$otp = (int)substr(str_shuffle($numb), 0, 6);
		$this->setOtp($otp) ;
		return $otp;
	}	


	/**
	 * Send otp code to user via mail or sms
	 * 
	*/
	public function sendOtp()
	{
		$pine = $this->GeneratePine();
		$url = "http://79.143.188.122:1401/send?username=ticanalyse&password=25az35&from=3424&to=226".$this->number."&content=".$this->otp;
		try 
		{
			file_get_contents($url);

		 } 
		    catch (Exception $e) 
		    {
                   	die();
             }                      
		                      
/*
		if (filter_var($this->login,FILTER_VALIDATE_EMAIL)) 
		{
			// Create the email and send the message
			$to = $this->login;  
			$email_subject = "Votre code pine de Validation : ";
			$email_body = $this->otp;
			$headers = "From: noreply@beoogolab.org\n"; 
			$headers .= "Reply-To: info@beoogolab.org";  

			mail($to,$email_subject,$email_body,$headers);	
			
		}
		else
		{			
			file_get_contents($url);
		}*/		


				

       
	}
}



 ?>